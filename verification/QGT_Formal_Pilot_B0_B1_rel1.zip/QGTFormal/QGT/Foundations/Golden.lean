/-
QGT Formal Pilot — Foundations: the golden quadratic ring.

We work inside the ring of integers of Q(sqrt 5) in the basis {1, phi}, i.e.
Z[phi], represented as pairs of integers. This is a DELIBERATE and declared
choice, recorded in FORMALIZATION_CONTRACT.md:

  * mathlib is not available in the build environment used for this pilot, so
    Real.sqrt is not imported;
  * every statement of B1_arith is an identity in Z[phi], which is exactly
    where Appendix L works (Z[sqrt5], the Fibonacci norm, the regular
    representation);
  * this is the WEAKEST FAITHFUL interpretation: identities are proved in the
    quadratic ring, and NO statement about Real is claimed.

Multiplication is forced by phi^2 = phi + 1, which is therefore a THEOREM of
the representation and not an axiom:

  (a + b phi)(c + d phi) = ac + bd + (ad + bc + bd) phi.
-/

namespace QGT

/-- An element `a + b*phi` of `Z[phi]`. -/
structure Zphi where
  a : Int
  b : Int
deriving DecidableEq, Repr

namespace Zphi

def ofInt (n : Int) : Zphi := ⟨n, 0⟩
def add (x y : Zphi) : Zphi := ⟨x.a + y.a, x.b + y.b⟩
def neg (x : Zphi) : Zphi := ⟨-x.a, -x.b⟩
def sub (x y : Zphi) : Zphi := add x (neg y)

/-- Multiplication induced by `phi^2 = phi + 1`. -/
def mul (x y : Zphi) : Zphi :=
  ⟨x.a * y.a + x.b * y.b, x.a * y.b + x.b * y.a + x.b * y.b⟩

instance : Add Zphi := ⟨add⟩
instance : Mul Zphi := ⟨mul⟩
instance : Neg Zphi := ⟨neg⟩
instance : Sub Zphi := ⟨sub⟩
instance : OfNat Zphi n := ⟨ofInt (Int.ofNat n)⟩

def pow (x : Zphi) : Nat → Zphi
  | 0     => ofInt 1
  | n + 1 => mul (pow x n) x

instance : HPow Zphi Nat Zphi := ⟨pow⟩

/-- The golden ratio. -/
def phi : Zphi := ⟨0, 1⟩

/-- `sqrt 5 = 2*phi - 1`. -/
def sqrt5 : Zphi := ⟨-1, 2⟩

/-- Integer scalar multiple. -/
def smul (n : Int) (x : Zphi) : Zphi := ⟨n * x.a, n * x.b⟩

/-! ### Commutative ring laws

The audit is entitled to ask whether `Zphi` really is a commutative ring, or
merely a pair type with two convenient operations. These are the laws, proved
for arbitrary elements, so the name is earned rather than asserted. -/

theorem add_comm (x y : Zphi) : x + y = y + x := by
  show Zphi.add x y = Zphi.add y x
  unfold Zphi.add; grind

theorem add_assoc (x y z : Zphi) : (x + y) + z = x + (y + z) := by
  show Zphi.add (Zphi.add x y) z = Zphi.add x (Zphi.add y z)
  unfold Zphi.add; grind

theorem add_zero (x : Zphi) : x + ofInt 0 = x := by
  show Zphi.add x (ofInt 0) = x
  unfold Zphi.add ofInt; grind

theorem add_neg (x : Zphi) : x + (-x) = ofInt 0 := by
  show Zphi.add x (Zphi.neg x) = ofInt 0
  unfold Zphi.add Zphi.neg ofInt; grind

theorem mul_comm (x y : Zphi) : x * y = y * x := by
  show Zphi.mul x y = Zphi.mul y x
  unfold Zphi.mul; grind

theorem mul_assoc (x y z : Zphi) : (x * y) * z = x * (y * z) := by
  show Zphi.mul (Zphi.mul x y) z = Zphi.mul x (Zphi.mul y z)
  unfold Zphi.mul; grind

theorem mul_one (x : Zphi) : x * ofInt 1 = x := by
  show Zphi.mul x (ofInt 1) = x
  unfold Zphi.mul ofInt; grind

theorem left_distrib (x y z : Zphi) : x * (y + z) = x * y + x * z := by
  show Zphi.mul x (Zphi.add y z) = Zphi.add (Zphi.mul x y) (Zphi.mul x z)
  unfold Zphi.mul Zphi.add; grind

theorem phi_sq : phi * phi = phi + 1 := by decide

theorem sqrt5_sq : sqrt5 * sqrt5 = 5 := by decide

theorem phi_inv : phi * (phi - 1) = 1 := by decide

theorem phi_add_inv : phi + (phi - 1) = sqrt5 := by decide

theorem phi_pow_four : phi ^ (4 : Nat) = ⟨2, 3⟩ := by decide

/-- The projection invariant `20 phi^4`, as an element of `Z[phi]`.
    NOT defined to be anything else: its value is computed. -/
def twentyPhiFour : Zphi := smul 20 (phi ^ (4 : Nat))

theorem twentyPhiFour_val : twentyPhiFour = ⟨40, 60⟩ := by decide

end Zphi
end QGT
