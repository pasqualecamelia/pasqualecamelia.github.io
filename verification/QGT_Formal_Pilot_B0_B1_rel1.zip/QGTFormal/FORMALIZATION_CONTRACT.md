# Formalization contract — QGT formal pilot, B0_min + B1_arith

Frozen authority: **QGT First Edition v7.6.6**, Appendix L, *The Projection
Constant*, pp. 529-537. Where the Python harness `qgt_block_alpha.py` and the
monograph differ, the monograph governs. The harness is a computational
specification and regression oracle, never the logical authority.

**No measured value of alpha, no CODATA value, no fitted parameter and no
experimental datum enters this project at any point.**

## Carrier: a declared deviation

mathlib is not reachable from the build environment used for this pilot, so
`Real.sqrt` is not imported. Every statement is therefore an identity in the
ring of integers of Q(sqrt 5), written in the basis {1, phi} as `Zphi`.

This is the **weakest faithful interpretation** in the sense required by the
mandate. Appendix L works in Z[sqrt5] — the Fibonacci norm, the regular
representation, the integer matrix `M_Pi` — so the arithmetic core lives
natively there. What is *not* claimed: any statement about the real numbers,
any embedding of `Zphi` into `Real`, any analytic property.

The multiplication of `Zphi` is induced by `phi^2 = phi + 1`; that identity is
consequently a **theorem of the representation** (`Zphi.phi_sq`), not an axiom.
Likewise `sqrt5 = 2*phi - 1` is a definition whose square is *proved* to be 5
(`Zphi.sqrt5_sq`).

## Definitions

| Object | Lean | Note |
|---|---|---|
| `phi` | `Zphi.phi = ⟨0,1⟩` | basis element |
| `sqrt5` | `Zphi.sqrt5 = ⟨-1,2⟩` | i.e. `2*phi - 1` |
| `20 phi^4` | `Zphi.twentyPhiFour = smul 20 (phi^4)` | **computed**, not defined as its value |
| Fibonacci | `fib` | recursion; `F_4`, `F_5` derived |
| chiral form | `chiralScaled` | `q^T [[0,1],[1,0]] q` |
| golden form | `goldenNorm a b` | assembled from the entries of `G` |
| regular rep. | `rho a b = [[a,5b],[b,a]]` | |
| evaluation | `evalSqrt5 a b` | `a + b*sqrt5` in the {1,phi} basis |

`twentyPhiFour` is never defined to be `⟨40,60⟩`; that value is a theorem
(`twentyPhiFour_val`). No target equality is hidden in a definition.

## Imported upstream hypotheses

Collected in `QGT/B0/RankFiveContract.lean` as the structure `RankSelection`,
whose fields are named individually:

- `rank = 5`;
- the coefficient vector is `(F_5, F_4)`.

**B1 consumes the rank-five selection; it does not re-prove its uniqueness.**
The physical selection theorem is upstream and is not formalized here. Every
B1 theorem that depends on the rank carries the contract as an explicit
hypothesis, so the dependency is visible in the signature.

## Proved conclusions

| Tag | Lean theorem | Statement |
|---|---|---|
| T1 | `chiral_contraction` | `q^T [[0,1],[1,0]] q = 2*(xi*eta)` for all integers |
| T2 | `pincherleReadout` | `Lambda_Pi^2 = 20 phi^4`, with `Lambda_Pi = 2 phi^2 sqrt5` |
| T3 | `fibonacciNormReadout` | `c_F^T G c_F = 20 phi^4` on the contract pair |
| T4 | `regularMatrixReadout` | `eval_sqrt5(M_Pi^2) = 20 phi^4` |
| T5 | `crossRepresentation` | T2 = T3 = T4 = `20 phi^4`, exactly |
| NC | `finiteRankSensitivity` | closure holds at r=5 and fails at r=3,4,6,7 |

## Declared weakenings

1. **Optional extensions E1 (SVD spectrum) and E2 (filter pole) are omitted.**
   Both need real or analytic structure — singular values, `log phi` — which
   lies outside `Zphi`. Formalizing them without mathlib would require building
   real analysis, far beyond a pilot. They remain in the Python harness as
   symbolic checks, at that lower level of assurance.
2. **The independent proof-term check is not established.** See
   `reports/BUILD_REPORT.md`. This is what keeps the pilot short of a
   high-assurance certificate.

Two weakenings present in the first candidate have been **removed**: T1 is now
proved over `Rat` in the monograph's own normalisation `q^T C_chi q = xi eta`,
and T4 and T5 are parametrised by the B0 contract, with the concrete matrix
kept as a named corollary. The commutative ring laws of the carrier are now
proved rather than assumed, so calling `Zphi` a ring is earned.

## What the pilot does not establish

It does not establish the physical truth of QGT; it does not establish that
the invariant is the measured fine-structure constant; it does not prove the
uniqueness of rank five; it does not derive the golden singular ladder. The
negative controls test sensitivity over a **finite declared set** and are not
a uniqueness proof.
