"""
qgt_core.py — Costanti strutturali, breathing, solitone, CMB
Derivato da: The Quantum Gauge Theory of Time (Camelia, 2026)

Ogni costante cita il capitolo sorgente.
Le identità algebriche sono verificate con assert al caricamento.

Livelli epistemici (dichiarati esplicitamente):
  LEVEL_A   : derivazioni chiuse, zero parametri liberi
  LEVEL_B   : connessioni fisiche + assunzioni addizionali
  OPEN_GATES: risultati parziali / porte aperte
"""

import numpy as np

# ════════════════════════════════════════════════════════════════
# Livelli epistemici (Cap00)
# ════════════════════════════════════════════════════════════════
LEVEL_A = [
    "alpha_inv = (5+3*sqrt5)^2 = 20*phi^4 = 500*Gamma_tau^4  [Cap09]",
    "sin^2(theta_W) = 3/13                                    [CapGauge]",
    "xi*eta = alpha_inv  (invariante breathing esatto)        [Cap02]",
    "a0_QGT = Gamma_tau^2 * M_B^2 * S^{-2r} m  (0.033 ppm)   [CapGate]",
    "m_mu/m_e via H_ker (H1=19, H2=43) e sigma1,sigma2        [CapMateria]",
    "T_CMB = pi/ln(pi) * (1 - 1/(sqrt(2)*100))               [Cap24]",
    "lock-in n=5: xi*eta=alpha_inv, B*=8                      [Cap14]",
]

LEVEL_B = [
    "R_infty = readout INTERNO di Pi+  (non ancora esterna)   [CapGate nota]",
    "BASE -> v_EW -> G_F  (Lemma 25, dim. formale in progress) [Cap25]",
    "m_tau/m_e: sigma3 candidata, non Level A                 [CapMateria]",
    "alpha_s = sqrt(140)/100  (accordo 0.3%, deriv. in prog.) [Cap09 nota]",
]

OPEN_GATES = [
    "kappa_QGT/G_N : normalizzazione gravitazionale assoluta",
    "Dirac 4D completa: loop self-consistenza lambda|Psi|^(2/3)",
    "G^{eta xi}_edge(k,ell): propagatore CMB multipolare",
    "sigma3: terza generazione leptonica (formula candidata)",
]

# ════════════════════════════════════════════════════════════════
# 1. COSTANTI STRUTTURALI  (Cap01, Cap02, Cap09)
# ════════════════════════════════════════════════════════════════

phi       = (1 + np.sqrt(5)) / 2          # sezione aurea  [Cap01]
Gamma_tau = phi / np.sqrt(5)              # Γ_τ = φ/√5     [Cap01]
alpha_inv = (5 + 3*np.sqrt(5))**2         # α⁻¹ strutturale [Cap09]
alpha     = 1.0 / alpha_inv

# Tre identità algebriche chiuse (LEVEL_A) — verificate al caricamento
assert abs(20*phi**4           - alpha_inv) < 1e-10, "20φ⁴ ≠ α⁻¹"
assert abs(500*Gamma_tau**4    - alpha_inv) < 1e-10, "500Γ_τ⁴ ≠ α⁻¹"
assert abs(2*np.sqrt(5)*phi**2 - np.sqrt(alpha_inv)) < 1e-10, "2√5φ² ≠ √α⁻¹"

r      = 5;  n_min = 2;  n_sat = 11;  n_lock = 5;  S = 10
n_conf = 7;  c_EW  = 13   # c_EW = 2r + |C_obs| = 10+3  [CapGauge]

lambda_eff = 16 * np.pi**2 * phi**12     # [CapSolitoni eq.lambda_eff]

# Fattore spettrale F_nm  [Cap16, CapReadout]
F_star  = 2*np.sqrt(5)*phi**2 / (3*np.pi)
f_gain  = (2*np.sqrt(5))**1.5 / (3*np.pi)
F_nm    = (2*np.sqrt(5))**2.5 * phi**2 / (9*np.pi**2)
assert abs(F_star * f_gain - F_nm) < 1e-10, "F_star*f_gain ≠ F_nm"
delta_F = 1 - 1/f_gain    # margine PLL ≈ 0.345%

# Lock-in anisotropico ξ*/η* = n_sat/n_lock = 11/5  [Cap14/P14]
xi_star  = n_sat  * np.sqrt(alpha_inv / (n_sat * n_lock))
eta_star = n_lock * np.sqrt(alpha_inv / (n_sat * n_lock))
assert abs(xi_star * eta_star - alpha_inv) < 1e-8, "ξ*·η* ≠ α⁻¹"

# Butterfly chirali  [CapMateria, CapClifford]
M_eta  = np.array([[2,1],[1,-1]], dtype=float) / n_min
M_xi   = np.array([[2,1],[1/np.sqrt(n_min),-1]], dtype=float) * np.sqrt(n_min)
# Valori singolari di M_eta = pulsazioni leptoniche generazioni 1, 2
sigma1 = np.sqrt((n_conf - np.sqrt(c_EW)) / (2*n_min**2))  # √((7-√13)/8)
sigma2 = np.sqrt((n_conf + np.sqrt(c_EW)) / (2*n_min**2))  # √((7+√13)/8)
Lambda = alpha_inv * 3 / 8    # in Q[√5]  [CapMateria]

# ════════════════════════════════════════════════════════════════
# 2. CASCATA ADIMENSIONALE — a0_QGT  [CapMateria, Cap16, Cap24]
# ════════════════════════════════════════════════════════════════
#
# a0_QGT = Γ_τ² · M_B² · S^{-2r}  [m]   (Cap. Gate Bohr-Rydberg)
#
# M_B² = 1 + ΔB/Γ_τ² dove ΔB è la correzione di scala:
#
#   ΔB = 3φ·S⁻³ + 3φ²·S⁻⁴ - 3√5·S⁻⁵ - n_min·S⁻⁶    (in Å)
#      = 3φ/1000 + 3φ²/10000 - 3√5/100000 - 2/1000000
#
# Termine k=3: coefficiente 3φ   (contributo radiale del lock-in n=5)
# Termine k=4: coefficiente 3φ²  (termine di curvatura φ²=φ+1)
# Termine k=5: coefficiente -3√5 (simmetria pentagonale: opposto)
# Termine k=6: coefficiente -n_min = -2  (correzione al confine)
#
# Riferimento: CapGate, eq. (Delta_B); BohrRydberg_LevelA_v2 (maggio 2026)

Delta_B   = (3*phi*1e-3 + 3*phi**2*1e-4 - 3*np.sqrt(5)*1e-5 - n_min*1e-6)
a0_static = phi**2 / 5                  # = Γ_τ² · S^{-2r}  (in Å)
eps_B     = Delta_B / a0_static         # correzione relativa
a0_QGT    = a0_static * (1 + eps_B) * 1e-10   # metri (LEVEL_A)

# Correzioni fisiche su alpha_inv  [Cap02 nota, CapGate nota]
eps7   = np.sqrt(5)*np.pi/7 - 1        # correzione settuple  [Cap02]
f_brea = phi / 5e6                     # frazione breathing   [CapBreathing]
alpha_inv_phys = (alpha_inv - c_EW*eps7) / (1 - f_brea)

# Nucleo di Heisenberg e masse leptoniche  [CapMateria]
H_ker   = [19, 43, 67]    # interi strutturali (primi nella sequenza del nucleo)
m_mu_me = H_ker[1]*sigma2 / (H_ker[0]*sigma1) * Lambda
# Nota: errore atteso ~0.5% — H_ker sono interi strutturali, non ottimizzati.
# L'accordo non è a livello ppm come alpha_inv. Vedere LEVEL_B.

T_CMB_QGT  = np.pi/np.log(np.pi) * (1 - 1/(np.sqrt(2)*100))  # [Cap24]
Omega_b_h2 = np.sqrt(5) / 100          # [Cap24]
Omega_c_h2 = 1 / (5*phi)               # [Cap24]
tau_pi     = phi**2/10 * 1e-7          # [CapMateria]

# ════════════════════════════════════════════════════════════════
# 3. BREATHING ODE  [Cap02, eq:breathing_hyp]
# ════════════════════════════════════════════════════════════════

def breathing_ode(t, y):
    """
    dξ/dt = -Γ_τ · ξ,   dη/dt = +Γ_τ · η.
    Invariante primo: ξ·η = α⁻¹ (esatto per le soluzioni analitiche).
    """
    xi, eta = y
    return [-Gamma_tau*xi, +Gamma_tau*eta]

def breathing_exact(t, xi0=None, eta0=None):
    """Soluzione analitica: ξ(t)=ξ₀e^{-Γ_τt}, η(t)=η₀e^{+Γ_τt}."""
    if xi0 is None: xi0 = xi_star
    if eta0 is None: eta0 = eta_star
    return xi0*np.exp(-Gamma_tau*t), eta0*np.exp(+Gamma_tau*t)

def theta_log(t, xi0=None, eta0=None):
    """θ_log = ½ ln(η/ξ). dθ_log/dt = Γ_τ esatto. [Cap02, eq:theta_log]"""
    xi, eta = breathing_exact(t, xi0, eta0)
    return 0.5 * np.log(eta / xi)

# ════════════════════════════════════════════════════════════════
# 4. RICORRENZA DI SCALA  [Cap02, eq:breath_rec]
# ════════════════════════════════════════════════════════════════

def breathing_map(B):
    """B_{k+1} = 2·B_k^{2/3}.  Punto fisso: B* = 8 (unico attrattore)."""
    return 2.0 * B**(2/3)

assert abs(breathing_map(8.0) - 8.0) < 1e-10, "B*=8 non è punto fisso"

# ════════════════════════════════════════════════════════════════
# 5. SOLITONE DI LOCK-IN  [CapSolitoni, eq:Psi_star]
# ════════════════════════════════════════════════════════════════

def ell_pen(H=1.0):
    """ℓ_pen = H/(π·α).  Lunghezza di penetrazione. H=1 in unità strutturali."""
    return H / (np.pi * alpha)

def soliton(n, H=1.0):
    """
    Ψ★(n) = φ · sech(n/ℓ_pen).
    Ampiezza φ da condizione di auto-consistenza R(e^{-2π}) = 1/φ.
    """
    return phi / np.cosh(n / ell_pen(H))

# Identità aurea: (φ + 1/φ) · sech(ln φ) = 2  (verifica algebrica)
assert abs((phi + 1/phi) / np.cosh(np.log(phi)) - 2.0) < 1e-14, "identità aurea fallita"

# ════════════════════════════════════════════════════════════════
# 6. DIRAC NONLINEARE STAZIONARIA 1D  [CapSolitoni]
# ════════════════════════════════════════════════════════════════
from scipy.integrate import solve_ivp

def nonlinear_dirac_ode(n, y, m_eff=1.0):
    """
    d²Ψ/dn² = m_eff²·Ψ - λ_eff·|Ψ|^{2/3}·Ψ.
    Condizioni al contorno di Neumann: Ψ'(0) = 0.
    Toy model 1D per il solitone di lock-in.
    """
    psi, dpsi = y
    return [dpsi, m_eff**2*psi - lambda_eff*np.abs(psi)**(2/3)*psi]

def solve_soliton_ode(n_max=5.0, m_eff=1.0, N=2000):
    sol = solve_ivp(nonlinear_dirac_ode, [0, n_max], [phi, 0.0],
                    args=(m_eff,), t_eval=np.linspace(0, n_max, N),
                    method='RK45', rtol=1e-9, atol=1e-11)
    return sol.t, sol.y[0]

# ════════════════════════════════════════════════════════════════
# 7. SPETTRO CMB  [CapSolitoni, eq:Cl_transfer + eq:Dl_sech2]
# ════════════════════════════════════════════════════════════════

def filter_H(z):
    """H(z) = P₄(z)/(1-α·z),  P₄(z) = Σ_{m=0}^4 (ln φ)^m z^m."""
    lp = np.log(phi)
    return sum(lp**m * z**m for m in range(5)) / (1 - alpha * z)

def C_ell(ell_arr):
    """C_ℓ = |H(e^{2πi/ℓ})|² · sech²(ℓ·π·α/2)."""
    out = np.zeros(len(ell_arr))
    for i, ell in enumerate(ell_arr):
        z = np.exp(2j*np.pi/ell)
        out[i] = abs(filter_H(z))**2 * (1/np.cosh(ell*np.pi*alpha/2))**2
    return out

def D_ell(ell_arr):
    """D_ℓ = 1 + Σ_{k=1}^6 φ^{-2k} · sech²((ℓ-ℓ_k)/σ_B(k)).  [CapSolitoni]"""
    D = np.ones_like(ell_arr, dtype=float)
    for k in range(1, 7):
        lk = alpha_inv * (k*phi + (k-1)/phi)
        sB = alpha_inv * Gamma_tau / k
        D += phi**(-2*k) * (1/np.cosh((ell_arr-lk)/sB))**2
    return D

# ════════════════════════════════════════════════════════════════
# Valori di riferimento CODATA 2018 / NIST
# ════════════════════════════════════════════════════════════════
CODATA = {
    'alpha_inv': 137.035999177,        # α⁻¹  (CODATA 2018)
    'R_inf':     10973731.568,         # R_∞  [m⁻¹]
    'T_CMB':     2.72548,              # T_CMB [K]  (Fixsen 2009)
    'm_mu_me':   206.7682830,          # mμ/mₑ (PDG 2022)
    'a0':        0.529177210903e-10,   # a₀   [m]  (CODATA 2018)
    'me_MeV':    0.51099895,           # mₑ   [MeV]
}

# CODATA 2018 separato (usato in P14 per errore 8.6e-8)
# P14 abstract cita CODATA 2018 = 137.035999084
# P14 table    cita CODATA 2022 = 137.035999177(21)
CODATA_2018_alpha_inv = 137.035999084   # CODATA 2018 (Mohr et al. Rev.Mod.Phys. 2021)
CODATA_2022_alpha_inv = 137.035999177   # CODATA 2022 = CODATA['alpha_inv']
