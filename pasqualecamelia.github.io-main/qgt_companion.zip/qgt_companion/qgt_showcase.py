"""
qgt_showcase.py — Quattro visualizzazioni notevoli della QGT
Derivato da: The Quantum Gauge Theory of Time (Camelia, 2026)

1. SPETTRO IDROGENO — livelli e transizioni con correzione QGT via δα
2. CASCATA α⁻¹ — convergenza a tre passi verso CODATA
3. FILTRO H(z) — selezione rango r=5 dal threshold crossing w_k vs α
4. DENSITÀ RADIALE — a₀_QGT vs a₀_standard overlay
"""

import numpy as np
from qgt_companion.qgt_core import (
    phi, Gamma_tau, alpha, alpha_inv,
    xi_star, eta_star, F_nm, delta_F,
    a0_QGT, filter_H, CODATA,
)

# Costanti
hc_eV    = 1.239841984e-6   # eV·m
R_inf_eV = 13.605693122994  # eV  (1 Rydberg)
R_inf_SI = 1.0973731568539e7  # m⁻¹

# ════════════════════════════════════════════════════════════════
# 1. SPETTRO IDROGENO QGT vs CODATA
# ════════════════════════════════════════════════════════════════

def hydrogen_spectrum_qgt(n_max=6):
    """
    Livelli energetici e transizioni dell'idrogeno.

    La correzione QGT viene dalla differenza tra α_QGT (dopo la cascata
    a 3 passi) e α_CODATA: δα/α ≈ 4.9e-11.

    Siccome E_n ∝ α²·m_e·c², la correzione ai livelli è:
        δE_n/E_n = 2·δα/α ≈ 9.8e-11

    E per le lunghezze d'onda: δλ/λ = −2·δα/α ≈ −0.098 ppb

    Questo è piccolo ma derivato senza parametri liberi — al contrario
    di QED che usa α come input.

    La cosa notevole NON è la dimensione della correzione,
    ma che α_QGT è DERIVATO dalla struttura del filtro,
    e la correzione ai livelli segue automaticamente.
    """
    # α dopo la cascata QGT (3 passi)
    sqrt5 = np.sqrt(5)
    a0_val = (5 + 3*sqrt5)**2
    eps7   = sqrt5 * np.pi / 7 - 1
    a1_val = a0_val - 13 * eps7
    f_b    = (1 + sqrt5) * 1e-7
    alpha_inv_qgt = a1_val / (1 - f_b)
    alpha_qgt = 1.0 / alpha_inv_qgt
    alpha_codata = 1.0 / CODATA['alpha_inv']

    # Livelli energetici: E_n = -R∞·α²/α_codata² / n²
    # ovvero E_n_QGT = E_n_std × (α_QGT/α_codata)²
    ratio2 = (alpha_qgt / alpha_codata)**2

    n_arr = np.arange(1, n_max+1)
    E_std = -R_inf_eV / n_arr**2
    E_qgt = E_std * ratio2

    dE_ppm = (E_qgt - E_std) / np.abs(E_std) * 1e6
    dE_ppb = dE_ppm * 1e3

    # Transizioni (emissione): lunghezze d'onda
    series_def = [
        ('Lyman',   1, list(range(2, n_max+1))),
        ('Balmer',  2, list(range(3, n_max+1))),
        ('Paschen', 3, list(range(4, n_max+1))),
    ]
    transitions = []
    for name, n_low, n_highs in series_def:
        for n_hi in n_highs:
            if n_hi > n_max: break
            dE_s = abs(E_std[n_low-1] - E_std[n_hi-1])
            dE_q = abs(E_qgt[n_low-1] - E_qgt[n_hi-1])
            lam_s = hc_eV / dE_s * 1e9   # nm
            lam_q = hc_eV / dE_q * 1e9   # nm
            dlam_fm = (lam_q - lam_s) * 1e6  # fm
            transitions.append({
                'series': name,
                'n_low': int(n_low), 'n_hi': int(n_hi),
                'label': f'{name} {n_low}→{n_hi}',
                'lam_std_nm': round(lam_s, 6),
                'lam_qgt_nm': round(lam_q, 6),
                'dlam_fm': round(dlam_fm, 4),
                'dlam_ppb': round((lam_q-lam_s)/lam_s*1e9, 6),
            })

    return {
        'n': n_arr.tolist(),
        'E_std_eV': [round(e,8) for e in E_std],
        'E_qgt_eV': [round(e,8) for e in E_qgt],
        'dE_ppb': [round(d,6) for d in dE_ppb],
        'alpha_qgt': float(alpha_qgt),
        'alpha_codata': float(alpha_codata),
        'alpha_inv_qgt': float(alpha_inv_qgt),
        'alpha_inv_codata': float(CODATA['alpha_inv']),
        'ratio_ppm': float((alpha_qgt/alpha_codata - 1)*1e6),
        'transitions': transitions,
        'note': 'Correzione derivata senza parametri liberi dalla struttura di H(z)',
    }


# ════════════════════════════════════════════════════════════════
# 2. CASCATA α⁻¹
# ════════════════════════════════════════════════════════════════

def alpha_cascade_steps():
    sqrt5 = np.sqrt(5)
    a0 = (5 + 3*sqrt5)**2
    eps7 = sqrt5 * np.pi / 7 - 1
    c_EW = 13
    a1 = a0 - c_EW * eps7
    f_b = (1 + sqrt5) * 1e-7
    a2 = a1 / (1 - f_b)
    target = CODATA['alpha_inv']

    return {
        'steps': [
            {'label': 'Step 0',
             'desc': 'Polo del filtro H(z): (5+3√5)²',
             'formula': '(5+3√5)²',
             'value': float(a0),
             'error_ppm': float((a0-target)/target*1e6)},
            {'label': 'Step 1',
             'desc': '−13·ε₇  correzione olonomica (n=7)',
             'formula': 'α₀⁻¹ − 13·(√5π/7−1)',
             'value': float(a1),
             'error_ppm': float((a1-target)/target*1e6)},
            {'label': 'Step 2',
             'desc': '÷(1−f_breath)  back-action breathing',
             'formula': 'α₁⁻¹ / (1−(1+√5)·10⁻⁷)',
             'value': float(a2),
             'error_ppb': float((a2-target)/target*1e9)},
        ],
        'target': float(target),
        'target_unc': 21e-9,
        'f_breath': float(f_b),
        'eps7': float(eps7),
    }


# ════════════════════════════════════════════════════════════════
# 3. FILTRO H(z) — rank selection
# ════════════════════════════════════════════════════════════════

def filter_rank_selection():
    K = 10
    k_arr = np.arange(K)
    z_k   = phi**(-k_arr.astype(float))
    w_k   = phi**(-(2*k_arr.astype(float)+1))
    sigma2 = phi**(-2*k_arr.astype(float))
    H_vals = np.array([abs(filter_H(z)) for z in z_k])
    cum    = np.cumsum(sigma2)/sigma2.sum()

    above = w_k > alpha
    r_sel = int(above.sum())

    return {
        'k': k_arr.tolist(),
        'w_k': [float(x) for x in w_k],
        'sigma2': [float(x) for x in sigma2],
        'H_vals': [float(x) for x in H_vals],
        'cum_energy': [float(x) for x in cum],
        'above': [bool(x) for x in above],
        'alpha': float(alpha),
        'r_selected': r_sel,
        'phi': float(phi),
        'note': f'r={r_sel} emerge dall\'unico threshold crossing w_k=α',
    }


# ════════════════════════════════════════════════════════════════
# 4. DENSITÀ RADIALE COMPARATIVA
# ════════════════════════════════════════════════════════════════

def hydrogen_density_comparison(N=120):
    """
    P(r) = r²|R_1s(r)|² per a₀_std e a₀_QGT.
    a₀_QGT = Γτ² Å ≈ 0.5236 Å  (QGT structural prediction)
    a₀_std = 0.5292 Å  (CODATA, usa α come input)
    Differenza: −1058 ppm (−0.106%)
    """
    # In unità Bohr (a0_std=1):
    a0_std = 1.0
    # a0_QGT in unità Bohr: Γτ² / 1 (adimensionale rispetto a a0_std in Bohr)
    # a0_QGT (SI) = 5.2918e-11 m  (questo è il valore del corpus in metri)
    # ma Γτ² = 0.5236 è la derivazione STRUTTURALE in Angstrom
    # La differenza: a0_std = 0.52918 Å, a0_QGT_struct = Γτ² Å = 0.52361 Å
    # In unità a0_std: a0_QGT = 0.52361/0.52918 = 0.98947
    a0_std_ang = 0.529177210903   # Å  CODATA
    a0_qgt_ang = float(Gamma_tau**2)  # = 0.5236 Å  (strutturale)
    a0_qgt_bohr = a0_qgt_ang / a0_std_ang  # in unità Bohr

    r = np.linspace(0.001, 20, N)
    dr = r[1] - r[0]

    def P1s(r_arr, a0):
        psi = (2/a0)**1.5 * np.exp(-r_arr/a0)
        return r_arr**2 * psi**2

    P_std = P1s(r, a0_std)
    P_qgt = P1s(r, a0_qgt_bohr)

    P_std /= P_std.sum()*dr
    P_qgt /= P_qgt.sum()*dr

    r_peak_std = float(r[np.argmax(P_std)])
    r_peak_qgt = float(r[np.argmax(P_qgt)])

    return {
        'r': [round(float(x),4) for x in r],
        'P_std': [round(float(x),6) for x in P_std],
        'P_qgt': [round(float(x),6) for x in P_qgt],
        'dP': [round(float(x),6) for x in P_qgt-P_std],
        'r_peak_std': round(r_peak_std, 4),
        'r_peak_qgt': round(r_peak_qgt, 4),
        'a0_std_ang': a0_std_ang,
        'a0_qgt_ang': a0_qgt_ang,
        'diff_ppm': round((a0_qgt_ang-a0_std_ang)/a0_std_ang*1e6, 1),
        'a0_qgt_bohr': round(a0_qgt_bohr, 8),
        'note': f'a₀_QGT = Γτ² = {a0_qgt_ang:.6f} Å  vs  a₀_std = {a0_std_ang:.6f} Å  (Δ = {(a0_qgt_ang-a0_std_ang)/a0_std_ang*1e6:.0f} ppm)',
    }


if __name__ == '__main__':
    print("1. SPETTRO")
    s = hydrogen_spectrum_qgt()
    print(f"   α_QGT⁻¹ = {s['alpha_inv_qgt']:.10f}")
    print(f"   α_CODATA⁻¹ = {s['alpha_inv_codata']:.10f}")
    print(f"   δα/α = {s['ratio_ppm']:.4f} ppm")
    for t in s['transitions'][:3]:
        print(f"   {t['label']}: λ_std={t['lam_std_nm']:.4f} nm, δλ={t['dlam_fm']:.2f} fm")

    print("\n2. CASCATA α⁻¹")
    c = alpha_cascade_steps()
    for st in c['steps']:
        err = st.get('error_ppb', st.get('error_ppm',''))
        unit = 'ppb' if 'error_ppb' in st else 'ppm'
        print(f"   {st['label']}: {st['value']:.10f}  err={err:.4f} {unit}")

    print("\n3. FILTRO H(z)")
    f = filter_rank_selection()
    print(f"   r = {f['r_selected']} (threshold α={f['alpha']:.4e})")
    for i in range(7):
        print(f"   k={i}: w={f['w_k'][i]:.4e} {'>' if f['above'][i] else '<'} α")

    print("\n4. DENSITÀ RADIALE")
    d = hydrogen_density_comparison()
    print(f"   {d['note']}")
    print(f"   r_peak_std = {d['r_peak_std']} a₀")
    print(f"   r_peak_qgt = {d['r_peak_qgt']} a₀")
