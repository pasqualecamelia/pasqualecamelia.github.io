"""
qgt_clifford.py — Clifford Cl(4,1), proiettori chirali, operatore di Dirac
Derivato da: The Quantum Gauge Theory of Time (Camelia, 2026) — CapClifford

Implementa la rappresentazione 4×4 esplicita (base Weyl) dell'algebra di
Clifford Cl(4,1) usata nella QGT, con le sue proprietà fisicamente rilevanti.

Struttura dell'algebra  [CapClifford]:
    {γ^μ, γ^ν} = 2η^{μν} I₄    (μ,ν = 0,1,2,3; firma (+,-,-,-))
    γ⁶ = √5 · γ⁵               (generatore aggiuntivo Cl(4,1))
    (γ⁶)² = 5 I₄
    {γ⁶, γ^μ} = 0  per μ=0..3

Proiettori chirali  [CapClifford]:
    P_φ+ = (I + γ⁵)/2   settore longitudinale → gravità
    P_φ- = (I - γ⁵)/2   settore trasversale   → EM

Coniugazione di carica Majorana  [CapClifford]:
    C = i · γ² · γ⁰
    Condizione Majorana: Ψ^c = C · conj(Ψ) = Ψ

Verifica della condizione Majorana su spinori fisici:
    La funzione majorana_condition_check(spinor, C) calcola il residuo
    ‖Ψ^c - Ψ‖/‖Ψ‖ e permette di testare spinori costruiti esternamente.
    Questo è un test FISICO, non solo algebrico.
"""

import numpy as np


def build_clifford_qgt():
    """
    Rappresentazione 4×4 esplicita (base Weyl) di Cl(4,1).

    Costruzione:
        γ⁰ = σ₁ ⊗ I₂               (boost temporale)
        γⁱ = iσ₂ ⊗ σᵢ  (i=1,2,3)  (boost spaziali)
        γ⁵ = σ₃ ⊗ I₂               (chiralità)
        γ⁶ = √5 · γ⁵               (generatore Cl(4,1))

    Tutte le identità algebriche sono verificate con assert.

    Ritorna
    -------
    g      : dict {0,1,2,3,5,6} → matrici 4×4 complesse
    P_plus : proiettore chirale + (gravità)
    P_minus: proiettore chirale - (EM)
    C      : matrice di coniugazione di carica (C² = -I)
    """
    s0 = np.eye(2, dtype=complex)
    s1 = np.array([[0, 1], [1, 0]], dtype=complex)
    s2 = np.array([[0,-1j],[1j, 0]], dtype=complex)
    s3 = np.array([[1, 0], [0,-1]], dtype=complex)

    g = {}
    g[0] = np.kron(s1,    s0)           # γ⁰
    g[1] = np.kron(1j*s2, s1)           # γ¹
    g[2] = np.kron(1j*s2, s2)           # γ²
    g[3] = np.kron(1j*s2, s3)           # γ³
    g[5] = np.kron(s3,    s0)           # γ⁵ = diag(+1,+1,-1,-1)
    g[6] = np.sqrt(5) * g[5]            # γ⁶ = √5·γ⁵

    I4      = np.eye(4, dtype=complex)
    P_plus  = 0.5*(I4 + g[5])           # P_φ+ (settore gravità)
    P_minus = 0.5*(I4 - g[5])           # P_φ- (settore EM)
    C       = 1j * g[2] @ g[0]          # coniugazione di carica

    # ── Verifica identità algebriche  [CapClifford] ──────────────
    eta = np.diag([1., -1., -1., -1.])
    for mu in range(4):
        for nu in range(4):
            comm = g[mu]@g[nu] + g[nu]@g[mu]
            assert np.allclose(comm, 2*eta[mu,nu]*I4), \
                f"{{γ^{mu}, γ^{nu}}} ≠ 2η^{{{mu}{nu}}}I"

    assert np.allclose(g[6]@g[6], 5*I4), "(γ⁶)² ≠ 5I"

    for mu in range(4):
        assert np.allclose(g[6]@g[mu] + g[mu]@g[6], 0), \
            f"{{γ⁶, γ^{mu}}} ≠ 0"

    assert np.allclose(P_plus @ P_minus, 0),  "P_φ+·P_φ- ≠ 0"
    assert np.allclose(P_plus + P_minus, I4), "P_φ+ + P_φ- ≠ I"

    # C² = -I  (condizione standard per matrice di coniugazione di carica)
    assert np.allclose(C @ C, -I4), "C² ≠ -I"

    # C† = -C  (C è antisimmetrica nel senso corretto: C^T = -C)
    assert np.allclose(C.T, -C), "C non è antisimmetrica (C^T ≠ -C)"

    return g, P_plus, P_minus, C


def dirac_operator(xi_val, eta_val, k_vec=None):
    """
    Operatore di Dirac linearizzato per spinore piano  [CapClifford]:

        M(k) = γ^μ·k_μ + α·ξ·I₄ + i·α·η·γ⁵

    Il termine di massa nonlineare λ|Ψ|^{2/3} deve essere iterato
    separatamente (non è incluso qui — gate aperto, CapSolitoni).

    Parametri
    ---------
    xi_val  : valore di ξ (componente gravitazionale del breathing)
    eta_val : valore di η (componente EM del breathing)
    k_vec   : quadri-vettore d'onda [k0,k1,k2,k3] (default: 0)
    """
    g, _, _, _ = build_clifford_qgt()
    I4 = np.eye(4, dtype=complex)
    if k_vec is None:
        k_vec = [0, 0, 0, 0]
    slash_k = sum(k_vec[mu]*g[mu] for mu in range(4))
    return slash_k + alpha_val(xi_val)*xi_val*I4 + 1j*alpha_val(eta_val)*eta_val*g[5]


def alpha_val(x):
    """α strutturale (costante — argomento ignorato, firma compatibile)."""
    from qgt_companion.qgt_core import alpha
    return alpha


def majorana_condition_check(spinor, C):
    """
    Verifica quantitativa della condizione Majorana:  Ψ^c = C·Ψ* = Ψ.

    Ritorna il residuo relativo ‖Ψ^c - Ψ‖ / ‖Ψ‖.
    Uno spinore Majorana ha residuo < 1e-10 (numerico).
    Uno spinore arbitrario ha residuo O(1).

    Questo test fisico permette di verificare che lo spinore del bulk
    soddisfi la condizione di neutralità di Majorana  [CapClifford].
    """
    psi_c = C @ spinor.conj()
    return np.linalg.norm(psi_c - spinor) / (np.linalg.norm(spinor) + 1e-300)


def build_majorana_spinor():
    """
    Costruisce uno spinore di Majorana esplicito nel settore P_φ+.

    Struttura: Ψ_M = (ψ, C·ψ*)  con ψ = (1, 0)^T  [CapClifford].
    Verifica: residuo Majorana < 1e-12.

    Ritorna spinore 4-componenti normalizzato.
    """
    g, P_plus, _, C = build_clifford_qgt()
    # Spinore chiralmente proiettato: prendo il primo autovettore di P_plus
    eigvals, eigvecs = np.linalg.eigh(P_plus)
    # Autovettore con autovalore 1 (settore +)
    psi_chiral = eigvecs[:, np.argmax(eigvals.real)]
    psi_chiral /= np.linalg.norm(psi_chiral)

    # Simmetrizza per soddisfare condizione Majorana: Ψ → (Ψ + CΨ*)/‖·‖
    psi_m = psi_chiral + C @ psi_chiral.conj()
    norm  = np.linalg.norm(psi_m)
    if norm < 1e-12:
        # Caso degenere: usa direttamente C·ψ* come secondo componente
        psi_m = psi_chiral
    else:
        psi_m /= norm

    residuo = majorana_condition_check(psi_m, C)
    return psi_m, residuo


def build_majorana_spinor():
    """
    Costruisce uno spinore di Majorana esplicito.

    La condizione di Majorana in questa rappresentazione Weyl è:
        Ψ^c = C · γ⁰ᵀ · Ψ* = Ψ
    (coniugazione di carica standard in QFT; non CΨ* = Ψ che non ha soluzione
    in 4D per questa scelta di C).

    Costruzione: autovettori reali di M = C·γ⁰ᵀ con autovalore +1.
    Due autovettori indipendenti → due spinori di Majorana indipendenti.

    Ritorna
    -------
    psi_m   : spinore di Majorana normalizzato (array 4-complessi, im=0)
    residuo : ‖Ψ^c - Ψ‖/‖Ψ‖  (atteso: 0 a precisione macchina)
    """
    g, _, _, C = build_clifford_qgt()

    # Operatore di coniugazione di carica standard
    M = C @ g[0].T

    # Autovettori reali con autovalore +1
    eigvals, eigvecs = np.linalg.eig(M.real)
    candidates = [(abs(v - 1.0), vec.astype(complex))
                  for v, vec in zip(eigvals, eigvecs.T)
                  if abs(v - 1.0) < 0.01]
    candidates.sort(key=lambda x: x[0])

    if not candidates:
        raise RuntimeError("Nessun autovettore Majorana trovato — check Cl(4,1)")

    psi_m = candidates[0][1]
    psi_m /= np.linalg.norm(psi_m)

    charge_conj = lambda psi: C @ g[0].T @ psi.conj()
    residuo = np.linalg.norm(charge_conj(psi_m) - psi_m) / np.linalg.norm(psi_m)
    return psi_m, residuo
