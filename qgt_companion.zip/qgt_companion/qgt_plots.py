"""
qgt_plots.py — Funzioni di plotting QGT
Derivato da: The Quantum Gauge Theory of Time (Camelia, 2026)

Dipende da: matplotlib, numpy
"""

import numpy as np

from qgt_companion.qgt_core import (
    phi, Gamma_tau, alpha, alpha_inv,
    xi_star, eta_star, sigma1, sigma2,
    M_eta, n_conf, n_min, c_EW,
    a0_QGT, lambda_eff,
    breathing_exact, theta_log,
    ell_pen, soliton, breathing_map,
    D_ell,
)
from qgt_companion.qgt_clifford import build_clifford_qgt, dirac_operator
from qgt_companion.qgt_hydrogen import (
    imaginary_time_propagation,
    hydrogen_radial_density,
    bohr_rydberg_cascade,
    BOHR_ANG,
)

# Palette colori QGT
C_BLUE  = '#534AB7'
C_GREEN = '#0F6E56'
C_RED   = '#993556'
C_GRAY  = '#888888'
C_GOLD  = '#A07820'


# ----------------------------------------------------------------
# Breathing
# ----------------------------------------------------------------
def plot_breathing(ax):
    t  = np.linspace(0, 8, 500)
    xi, eta = breathing_exact(t)
    th = theta_log(t)
    ax.plot(t, xi,  color=C_BLUE,  lw=1.5, label='ξ (gravità)')
    ax.plot(t, eta, color=C_GREEN, lw=1.5, label='η (EM)')
    ax.plot(t, th * max(eta)/max(th), color=C_RED, lw=1, ls='--',
            label='θ_log (tempo)')
    ax.axhline(alpha_inv, color=C_GRAY, lw=0.5, ls=':', label='α⁻¹ (invariante)')
    ax.set_xlabel('t · Γ_τ', fontsize=10)
    ax.set_title('Breathing — rotazione iperbolica: ξη = α⁻¹', fontsize=10)
    ax.legend(fontsize=8, loc='upper right')
    ax.text(0.02, 0.95, f'ξ·η = α⁻¹ = {alpha_inv:.4f} esatto',
            transform=ax.transAxes, fontsize=7, va='top', color=C_GRAY)


# ----------------------------------------------------------------
# Solitone
# ----------------------------------------------------------------
def plot_soliton(ax):
    lp = ell_pen()
    n  = np.linspace(-5*lp, 5*lp, 800)
    ax.plot(n/lp, soliton(n), color=C_BLUE, lw=2, label='sech (solitone)')
    ax.plot(n/lp, phi*np.exp(-(n/lp)**2/2), color=C_GRAY, lw=1,
            ls='--', label='Gaussiana')
    ax.plot(n/lp, np.abs(np.tanh(n/lp)), color=C_GREEN, lw=1,
            ls=':', label='|tanh| (parete)')
    ax.axvline(0, color='#ccc', lw=0.5)
    ax.axhline(phi, color=C_BLUE, lw=0.5, ls=':')
    ax.text(0.02, 0.97, f'|Ψ★|(0) = φ = {phi:.6f}',
            transform=ax.transAxes, fontsize=7, va='top', color=C_BLUE)
    ax.text(0.02, 0.91, f'ℓ_pen = H/(πα) = {lp:.1f}',
            transform=ax.transAxes, fontsize=7, va='top', color=C_GRAY)
    ax.set_xlabel('n / ℓ_pen', fontsize=10)
    ax.set_title('Solitone Ψ★(n) = φ·sech(n/ℓ_pen)', fontsize=10)
    ax.legend(fontsize=8)


# ----------------------------------------------------------------
# Ricorrenza di scala
# ----------------------------------------------------------------
def plot_scale_cascade(ax):
    B0s = [0.1, 1.0, 5.0, 20.0, 100.0]
    for B0 in B0s:
        traj = [B0]; B = B0
        for _ in range(40):
            B = breathing_map(B); traj.append(B)
        ax.plot(traj, lw=1, alpha=0.7, label=f'B₀={B0}')
    ax.axhline(8, color=C_RED, lw=1.5, ls='--', label='B★=8 (attrattore)')
    ax.set_xlabel('passi k', fontsize=10)
    ax.set_title('Ricorrenza B_{k+1}=2B_k^{2/3} → B★=8', fontsize=10)
    ax.legend(fontsize=7, ncol=2)
    ax.set_ylim(0, 25)


# ----------------------------------------------------------------
# Butterfly / SVD
# ----------------------------------------------------------------
def plot_butterfly(ax):
    theta = np.linspace(0, 2*np.pi, 300)
    circle_x = np.cos(theta)
    circle_y = np.sin(theta)
    pts    = np.stack([circle_x, circle_y])
    mapped = M_eta @ pts
    ax.plot(circle_x, circle_y, color=C_GRAY, lw=0.8, ls='--',
            label='cerchio unitario')
    ax.plot(mapped[0], mapped[1], color=C_BLUE, lw=1.5, label='M_eta (ellisse)')
    ax.axhline(0, color='#ccc', lw=0.5)
    ax.axvline(0, color='#ccc', lw=0.5)
    ax.set_aspect('equal')
    ax.set_title(f'SVD di M_eta: σ₁={sigma1:.4f}, σ₂={sigma2:.4f}\n'
                 '= pulsazioni masse leptoniche', fontsize=9)
    ax.legend(fontsize=8)
    ax.text(0.02, 0.05,
            f'‖M_eta‖²_F = {np.sum(M_eta**2):.4f} = 7/4 = n_conf/n_min²',
            transform=ax.transAxes, fontsize=7, color=C_GRAY)


# ----------------------------------------------------------------
# DNA
# ----------------------------------------------------------------
def dna_helix(n_turns=1, steps_per_turn=10, angle_deg=36.0):
    """
    B-DNA come Class 2 (2:5) della Dirac nonlineare alla scala k=3.
    BUG FIX: z non moltiplicata per n_turns (bug originale).
    """
    N = n_turns * steps_per_turn * 20
    t = np.linspace(0, n_turns * 2*np.pi, N)
    angle_rad = np.deg2rad(angle_deg)
    freq = steps_per_turn / (2*np.pi) * angle_rad
    r_h  = 1.0
    # CORRETTO: pitch = 3.4 nm, z va da 0 a n_turns * 3.4 nm
    z    = t / (2*np.pi) * 3.4   # nm — z[max] = n_turns * 3.4 nm
    x1   = r_h * np.cos(freq * t)
    y1   = r_h * np.sin(freq * t)
    x2   = r_h * np.cos(freq * t + np.pi)
    y2   = r_h * np.sin(freq * t + np.pi)
    return (x1, y1, z), (x2, y2, z)

def plot_dna(ax):
    (x1,y1,z), (x2,y2,_) = dna_helix(n_turns=2)
    ax.plot(x1, z, color=C_BLUE,  lw=1.5, label='filone ξ (backbone)')
    ax.plot(x2, z, color=C_GREEN, lw=1.5, label='filone η (basi)')
    steps = 20
    for k in range(steps+1):
        i = int(k/steps*(len(z)-1))
        ax.plot([x1[i], x2[i]], [z[i], z[i]], color='#ccc', lw=0.6, zorder=0)
    ax.set_xlabel('x (raggio normalizzato)', fontsize=9)
    ax.set_ylabel('z (nm)', fontsize=9)
    ax.set_title('B-DNA: Class 2 (2:5), k=3\n36°=π/5 per passo, 10 passi/giro', fontsize=9)
    ax.legend(fontsize=8)
    ax.text(0.02, 0.97, 'Ψ⁻ = CΨ̄⁺ (condizione Majorana)',
            transform=ax.transAxes, fontsize=7, va='top', color=C_GRAY)
    # Annotazione pitch corretto
    ax.text(0.98, 0.03, f'pitch = {z[-1]:.1f} nm ({int(round(z[-1]/3.4))} giri)',
            transform=ax.transAxes, fontsize=7, ha='right', color=C_GRAY)


# ----------------------------------------------------------------
# CMB
# ----------------------------------------------------------------
def plot_cmb(ax):
    ell = np.linspace(2, 2200, 1200)
    ax.plot(ell, D_ell(ell), color=C_BLUE, lw=2, label='QGT strutturale')
    planck_obs = [220, 540, 810, 1120, 1400, 1560]
    for i, lo in enumerate(planck_obs):
        ax.axvline(lo, color=C_RED, lw=0.6, ls='--', alpha=0.6,
                   label='Planck 2018' if i == 0 else None)
    ax.set_xlabel('ℓ (multipolo)', fontsize=10)
    ax.set_ylabel('D_ℓ (normalizzato)', fontsize=10)
    ax.set_title('Spettro CMB: 6 picchi sech² strutturali\n'
                 'zero parametri liberi', fontsize=9)
    ax.legend(fontsize=8)
    for k in range(1, 7):
        lk = alpha_inv*(k*phi + (k-1)/phi)
        ax.text(lk, 0.85, f'ℓ_{k}', fontsize=7, ha='center', color=C_BLUE)


# ----------------------------------------------------------------
# Clifford
# ----------------------------------------------------------------
def plot_clifford(ax):
    g, Pp, Pm, C = build_clifford_qgt()
    mats  = [g[0].real, g[5].real, g[6].real, Pp.real, Pm.real]
    names = ['γ⁰', 'γ⁵', 'γ⁶=√5·γ⁵', 'P_φ+', 'P_φ-']
    n = len(mats)
    for i, (M, name) in enumerate(zip(mats, names)):
        ax2 = ax.inset_axes([i/n + 0.01, 0.1, 1/n - 0.02, 0.8])
        ax2.imshow(M, cmap='RdBu', vmin=-2.5, vmax=2.5, aspect='equal')
        ax2.set_title(name, fontsize=8)
        ax2.set_xticks([]); ax2.set_yticks([])
    ax.set_axis_off()
    ax.set_title('Cl(4,1) — matrici esplicite base Weyl\n'
                 'γ⁶ = √5·γ⁵  |  P_φ± = (I ± γ⁵)/2', fontsize=9)


# ----------------------------------------------------------------
# Idrogeno statico (densità radiale)
# ----------------------------------------------------------------
def plot_atom_static(axes):
    a0_A = BOHR_ANG
    for idx, n in enumerate([1,2,3,4]):
        ax = axes[idx]
        r_max = n*n*a0_A*4 + a0_A
        r = np.linspace(0.01, r_max, 1000)
        P = hydrogen_radial_density(r, n, a0_A)
        ax.fill_between(r, P, alpha=0.15, color=C_GREEN)
        ax.plot(r, P, color=C_GREEN, lw=1.5)
        ax.axvline(n*n*a0_A, color=C_RED, lw=0.8, ls='--')
        En = -13.605693 / n**2
        ax.text(0.97, 0.95, f'n={n}\nE={En:.3f} eV',
                transform=ax.transAxes, fontsize=7, ha='right', va='top')
        ax.set_xlabel('r (Å)', fontsize=8)
        if idx == 0:
            ax.set_title(f'H atom — a₀={a0_A:.5f} Å (QGT LEVEL_A)', fontsize=9)


# ----------------------------------------------------------------
# Idrogeno DINAMICO — evoluzione in tempo immaginario
# ----------------------------------------------------------------
def plot_hydrogen_lockin(ax_convergence, ax_density, ax_virial=None):
    """
    Grafico principale della simulazione dinamica:
        sinistra: convergenza dell'energia verso -13.6057 eV
        destra:   densità radiale finale vs. esatta
        (opz):    verifica del teorema del viriale
    """
    print("  Simulazione ITP idrogeno in corso...", end=" ", flush=True)
    res = imaginary_time_propagation(N=600, rho_max=25.0,
                                     n_steps=1200, dtau=0.04)
    print("fatto.")

    E_exact = res['E_exact_eV']
    rho     = res['rho']
    P       = res['P_final']
    energies = res['energies']
    taus     = res['taus']

    # --- Pannello convergenza ---
    ax_convergence.plot(taus, energies, color=C_BLUE, lw=1.2,
                        label='E(τ) QGT-ITP')
    ax_convergence.axhline(E_exact, color=C_RED, lw=1.2, ls='--',
                           label=f'E_1 esatto = {E_exact:.4f} eV')
    ax_convergence.axhline(res['energy_ev'], color=C_GREEN, lw=0.8, ls=':',
                           label=f'E_finale = {res["energy_ev"]:.4f} eV')
    ax_convergence.set_xlabel('τ (tempo immaginario)', fontsize=10)
    ax_convergence.set_ylabel('E (eV)', fontsize=10)
    ax_convergence.set_title('Convergenza ITP → stato 1s\n'
                             f'a₀_QGT = {BOHR_ANG:.5f} Å  (LEVEL_A)',
                             fontsize=9)
    ax_convergence.legend(fontsize=8)
    conv_str = '✓ converge' if res['converged'] else '△ in progress'
    ax_convergence.text(0.98, 0.12, conv_str,
                        transform=ax_convergence.transAxes,
                        fontsize=9, ha='right', color=C_GREEN if res['converged'] else C_GOLD)

    # --- Pannello densità ---
    # Soluzione esatta 1s per confronto
    P_exact_1s = 4 * rho**2 * np.exp(-2*rho)
    P_exact_1s /= np.trapezoid(P_exact_1s, rho)
    P_norm = P / np.trapezoid(P, rho)

    ax_density.fill_between(rho, P_norm, alpha=0.2, color=C_BLUE)
    ax_density.plot(rho, P_norm,    color=C_BLUE,  lw=2,   label='ITP finale')
    ax_density.plot(rho, P_exact_1s, color=C_RED, lw=1.2, ls='--',
                    label='1s esatto')
    ax_density.axvline(1.0, color=C_RED,  lw=0.7, ls=':',
                       label=f'r_peak = a₀_QGT')
    ax_density.axvline(res['r_peak_qgt'], color=C_BLUE, lw=0.7, ls=':',
                       label=f'r_peak ITP = {res["r_peak_qgt"]:.3f} a₀')
    ax_density.set_xlim(0, 8)
    ax_density.set_xlabel('ρ = r / a₀_QGT', fontsize=10)
    ax_density.set_ylabel('P(ρ)  (normalizzata)', fontsize=10)
    ax_density.set_title(f'Densità radiale stato 1s\n'
                         f'⟨r⟩ = {res["r_mean_qgt"]:.3f} a₀  '
                         f'(esatto: 3/2 = {1.5:.3f})',
                         fontsize=9)
    ax_density.legend(fontsize=8)

    # Viriale
    vir = res['virial']
    T   = res['T_exp_au']
    V   = res['V_exp_au']
    ax_density.text(0.98, 0.30,
                    f'2⟨T⟩+⟨V⟩ = {vir:+.4f} a.u.\n'
                    f'⟨T⟩={T:.4f}  ⟨V⟩={V:.4f}',
                    transform=ax_density.transAxes,
                    fontsize=7, ha='right', va='top', color=C_GRAY)

    if ax_virial is not None:
        # Mini pannello viriale
        n_check = min(len(energies), 400)
        ax_virial.plot(taus[:n_check], energies[:n_check],
                       color=C_BLUE, lw=1, label='E(τ)')
        ax_virial.axhline(E_exact, color=C_RED, lw=0.8, ls='--')
        ax_virial.set_title('Convergenza (zoom)', fontsize=8)
        ax_virial.set_xlabel('τ', fontsize=8)

    return res
