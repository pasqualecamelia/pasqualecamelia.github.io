# QGT beta_11 — same-effective-action reproducibility witness r01

## Question
Can the mixed atom–light readout coefficient `beta_11` be obtained by four sign-reversed evolutions of the **same Schrödinger-grade effective action** that contains both the Coulomb atom and the dipole light perturbation?

## Answer tested here
Yes, conditionally at Schrödinger grade. The code uses one Hamiltonian

`H[E](t) = -1/2 nabla^2 - 1/r - E(t) z`

and two independently sign-reversed pulse envelopes. From the four survival amplitudes `M_br=<1s|U_br|1s>` it extracts

`beta_11 = (1/4) Arg[(M_++ M_--)/(M_+- M_-+)]`

on the continuous weak-response branch.

In the weak, adiabatic limit the same-action prediction is

`beta_11 = alpha_1s * eps1 * eps2 * Integral f1(t) f2(t) dt`

so the normalized coefficient `alpha_eff = beta_11/(eps1 eps2 I12)` must converge to the static 1s polarizability.

## Independent workstreams
1. **Static response:** radial Sternheimer equation from the same Coulomb Hamiltonian. No dynamic four-sign data are used.
2. **Dynamic response:** partial-wave TDSE, four sign configurations, Walsh-11 phase extraction.
3. **Red-team:** zero-overlap pulses, weak-amplitude scaling, norm conservation, weak-excitation check.
4. **Reproducibility:** frozen numerical parameters, CSV/JSON outputs and SHA-256 manifest.

## Frozen numerical model
- radial grid: `dr=0.05`, `rmax=50`
- partial waves: `l=0,1,2`, `m=0`
- real-time step: `dt=0.05`
- H0 half-step: Crank–Nicolson/Cayley
- field step: exact exponential of the local `-E(t) r cos(theta)` angular matrix
- pulses: smooth `sin^2` envelopes

## Scientific status
**Closed here:**
- algebraic identification of `beta_11` as the Walsh/Hadamard mixed `(1,1)` channel;
- a reproducible same-effective-action Schrödinger-grade witness;
- convergence of dynamic `beta_11` toward the independently computed static Coulomb polarizability.

**Not closed here:**
- derivation of the absolute electromagnetic field/charge normalization from the microscopic QGT parent;
- proof that the physical QGT response jet and moving access uniquely reduce to the length-gauge `-E z` interaction;
- radiative QED corrections and spontaneous photon emission.

Therefore this bundle is a **downstream physical-closure witness**, not a claim that the upstream QGT parent-normalization gate is solved.

## Run
```bash
python qgt_beta11_repro.py
```
A reduced sweep is available with:
```bash
python qgt_beta11_repro.py --quick
```

Dependencies: Python 3, NumPy, SciPy, Matplotlib (plots only).
