# QGT Minimal Qubit–Hadamard Closure r01

## Claim

Within the **minimal coherent two-way readout class**, a two-way readable relation carries a
two-dimensional complex Hilbert fibre and its parity-resolving lossless readout is the Hadamard
basis, uniquely up to branch rephasing, output phases and exchange of the two output labels.

This is a theorem about the declared class. It is **not** a theorem that every two-valued classical
record is a qubit, nor that the complete Fibonacci–Mellin transform is a radix-2 FFT.

## Hypotheses

Let two physically distinguishable coherent alternatives span a minimal invariant readable fibre
\(\mathcal H_2=\mathrm{span}\{|L\rangle,|H\rangle\}\). Assume:

1. \(|L\rangle,|H\rangle\) are orthonormal after the physical access metric is whitened/restricted
   to the non-null readable quotient.
2. There is a nontrivial **unitary involution** \(J\) exchanging the two alternatives.
3. The local readout is lossless and is required to resolve the two parity sectors of \(J\).
4. No extra readable direction is retained (minimality).

## Theorem 1 — minimal carrier

Two linearly independent coherent alternatives require
\(\dim_\mathbb C\mathcal H\ge 2\). Minimality therefore gives
\(\mathcal H_2\simeq\mathbb C^2\): a qubit carrier.

If coherence is not physically available, the observable algebra may reduce to a classical bit
\(\mathbb C\oplus\mathbb C\). The theorem concerns the coherent carrier.

## Theorem 2 — exchange normal form and unique Hadamard readout

After branch rephasing, every unitary involution exchanging the two alternatives has the form

\[
J_\phi=
\begin{pmatrix}
0 & e^{-i\phi}\\
e^{i\phi}&0
\end{pmatrix},
\qquad J_\phi^2=I,\quad J_\phi^\dagger=J_\phi.
\]

Its eigenvalues are \(+1,-1\), with normalized eigenvectors

\[
|+\rangle_\phi=\frac{|L\rangle+e^{i\phi}|H\rangle}{\sqrt2},\qquad
|-\rangle_\phi=\frac{|L\rangle-e^{i\phi}|H\rangle}{\sqrt2}.
\]

Therefore a parity readout is

\[
U_\phi
=H\,\mathrm{diag}(1,e^{-i\phi}),
\qquad
H=\frac1{\sqrt2}
\begin{pmatrix}1&1\\1&-1\end{pmatrix}.
\]

It satisfies

\[
U_\phi J_\phi U_\phi^\dagger=\mathrm{diag}(1,-1).
\]

Because the eigenspaces are one-dimensional, every other unitary parity diagonalizer differs
only by output phases and/or exchange of the \(+\) and \(-\) labels. Hence **Hadamard is unique
in the declared class up to gauge and labeling**.

## Corollary — the readout is bilinear/interferometric

For \(\Psi=(L,H)^T\),

\[
p_\pm=\|P_\pm\Psi\|^2
=\frac12\left(S_0\pm 2\operatorname{Re}[e^{-i\phi}L^*H]\right).
\]

The parity readout therefore converts the off-diagonal coherence \(L^*H\) into a population
difference. This is the precise sense in which the minimal coherent two-way grammar is
interferometric.

## Theorem 3 — multiple binary relations and Walsh characters

For two commuting binary reversals the configuration group is
\(G=\mathbb Z_2\times\mathbb Z_2\). Its four irreducible characters are

\[
1,\quad s_1,\quad s_2,\quad s_1s_2.
\]

The Fourier transform of \(G\) is the Walsh–Hadamard transform \(H\otimes H\). For a scalar
output \(F(s_1,s_2)\),

\[
F_{11}=\frac14\sum_{s_1,s_2=\pm1}s_1s_2F(s_1,s_2)
=\frac14(F_{++}-F_{+-}-F_{-+}+F_{--}).
\]

This is the unique component odd under either single reversal and even under simultaneous
reversal: the irreducible mixed relation.

## Theorem 4 — continuous mixed-response limit

For smooth \(F(\epsilon_1,\epsilon_2)\),

\[
\frac{F(\epsilon,\epsilon)-F(\epsilon,-\epsilon)
-F(-\epsilon,\epsilon)+F(-\epsilon,-\epsilon)}
{4\epsilon^2}
\to
\partial_{\epsilon_1}\partial_{\epsilon_2}F(0,0).
\]

Thus the Walsh \(11\) channel is the discrete counterpart of the mixed Hessian.

## QGT closure statement

The QFMT/SST local two-sheet carrier already realizes the hypotheses of Theorems 1–2:
a two-component coherent fibre, a lossless local sum/difference butterfly, Hadamard axis
conjugation, and a projective phase readout.

Therefore, within the declared coherent finite-readout class,

\[
\boxed{
\text{two-way coherent relation}
\Rightarrow
\mathbb C^2\text{ minimal carrier}
\Rightarrow
\text{Hadamard parity basis}
\Rightarrow
\text{Walsh characters for multiple binary relations}.
}
\]

The strong statement is:

> **The qubit/Hadamard pair is the unique minimal coherent, lossless grammar for reading a
> unitary two-way exchange, up to gauge and relabeling.**

Not implied:
- every two-valued classical record is a qubit;
- every physical relation in Nature satisfies the hypotheses;
- the complete FMT is a radix-2/Walsh transform;
- the QGT parent has already been shown to select every physical two-way relation;
- absolute electromagnetic normalization or empirical validation.
