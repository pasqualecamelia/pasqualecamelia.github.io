"""
__main__.py — Entry point per python -m qgt_companion

Uso:
  python -m qgt_companion verify              # verifica strutturale
  python -m qgt_companion hydrogen            # simulazione ITP idrogeno
  python -m qgt_companion all                 # verify + hydrogen
  python -m qgt_companion all --plot          # tutto + grafici
  python -m qgt_companion plot breathing soliton cmb
"""

import sys


def main():
    args = sys.argv[1:]
    do_plot  = '--plot' in args
    args     = [a for a in args if a != '--plot']
    command  = args[0] if args else 'all'
    plot_sel = args[1:] if len(args) > 1 else None

    if command in ('verify', 'all'):
        from qgt_companion.qgt_verify import run_verify
        run_verify()

    if command in ('hydrogen', 'all'):
        print("\n" + "="*64)
        print("QGT HYDROGEN LOCK-IN SIMULATOR (LEVEL_A)")
        print("="*64)
        from qgt_companion.qgt_hydrogen import (
            imaginary_time_propagation, bohr_rydberg_cascade
        )
        print("\n▸ Cascata Bohr-Rydberg:")
        cas = bohr_rydberg_cascade()
        print(f"  a₀_QGT  = {cas['a0_QGT_ang']:.7f} Å  (err {cas['err_a0_ppm']:.3f} ppm)")
        print(f"  R_∞     = {cas['R_infty_QGT']:.4f} m⁻¹  (err {cas['err_Rinf_ppm']:.3f} ppm)")
        print(f"  mₑ      = {cas['me_QGT_MeV']:.6f} MeV  (err {cas['err_me_pct']:.4f}%)")

        print("\n▸ Simulazione ITP in corso (tempo immaginario)...")
        res = imaginary_time_propagation(N=600, rho_max=25.0,
                                         n_steps=1200, dtau=0.04,
                                         verbose=True)
        print(f"\n  Energia finale  = {res['energy_ev']:.6f} eV")
        print(f"  Energia esatta  = {res['E_exact_eV']:.6f} eV")
        print(f"  Errore          = {abs(res['energy_ev']-res['E_exact_eV'])*1000:.3f} meV")
        print(f"  r_peak          = {res['r_peak_qgt']:.4f} a₀  (esatto: 1.0000)")
        print(f"  <r>             = {res['r_mean_qgt']:.4f} a₀  (esatto: 1.5000)")
        print(f"  2<T>+<V>        = {res['virial']:+.6f} a.u.  (→ 0 teorema viriale)")
        print(f"  Convergenza     : {'✓ OK' if res['converged'] else '△ in progress'}")

    if do_plot:
        _run_plots(plot_sel)


def _run_plots(which=None):
    try:
        import matplotlib
        matplotlib.use('Agg')  # non-interactive, per compatibilità
        import matplotlib.pyplot as plt
        import matplotlib.gridspec as gridspec
    except ImportError:
        print("matplotlib non installato: pip install matplotlib")
        return

    from qgt_companion.qgt_plots import (
        plot_breathing, plot_soliton, plot_scale_cascade,
        plot_butterfly, plot_dna, plot_cmb, plot_clifford,
        plot_atom_static, plot_hydrogen_lockin,
    )

    ALL = ['verify', 'breathing', 'soliton', 'scale',
           'butterfly', 'dna', 'cmb', 'clifford',
           'atom', 'hydrogen']

    if which is None:
        which = ALL
    which = [w for w in which if w in ALL]

    # ---- Layout --------------------------------------------------------
    # hydrogen occupa 2 pannelli larghi (convergenza + densità)
    # atom occupa 4 pannelli stretti
    # tutti gli altri: 1 pannello largo ogni 2 colonne

    NCOLS = 4
    COL_W = 4.0
    ROW_H = 3.8
    ATOM_H = 3.2
    HYD_H  = 4.0

    special = {'atom', 'hydrogen'}
    others  = [w for w in which if w not in special and w != 'verify']

    rows = []
    i = 0
    while i < len(others):
        if i+1 < len(others):
            rows.append([others[i], others[i+1]]); i += 2
        else:
            rows.append([others[i]]); i += 1
    if 'atom'     in which: rows.append(['atom'])
    if 'hydrogen' in which: rows.append(['hydrogen'])

    if not rows:
        return

    heights = []
    for row in rows:
        if row == ['atom']:     heights.append(ATOM_H)
        elif row == ['hydrogen']: heights.append(HYD_H)
        else:                   heights.append(ROW_H)

    fig_h = sum(heights) + 1.0
    fig   = plt.figure(figsize=(NCOLS*COL_W, fig_h), facecolor='white')
    fig.suptitle('QGT Companion Simulator v2.0\n'
                 'The Quantum Gauge Theory of Time — Camelia 2026',
                 fontsize=12, y=0.99)

    gs = gridspec.GridSpec(len(rows), NCOLS, figure=fig,
                           hspace=0.60, wspace=0.38,
                           top=0.95, bottom=0.05,
                           left=0.07, right=0.97,
                           height_ratios=heights)

    dispatch = {
        'breathing': plot_breathing,
        'soliton':   plot_soliton,
        'scale':     plot_scale_cascade,
        'butterfly': plot_butterfly,
        'dna':       plot_dna,
        'cmb':       plot_cmb,
        'clifford':  plot_clifford,
    }

    for row_i, row in enumerate(rows):
        if row == ['atom']:
            axes = [fig.add_subplot(gs[row_i, j]) for j in range(4)]
            plot_atom_static(axes)
        elif row == ['hydrogen']:
            ax_left  = fig.add_subplot(gs[row_i, 0:2])
            ax_right = fig.add_subplot(gs[row_i, 2:4])
            plot_hydrogen_lockin(ax_left, ax_right)
        elif len(row) == 2:
            ax0 = fig.add_subplot(gs[row_i, 0:2])
            ax1 = fig.add_subplot(gs[row_i, 2:4])
            if row[0] in dispatch: dispatch[row[0]](ax0)
            if row[1] in dispatch: dispatch[row[1]](ax1)
        else:
            ax = fig.add_subplot(gs[row_i, 0:4])
            if row[0] in dispatch: dispatch[row[0]](ax)

    plt.savefig('qgt_simulation.pdf', dpi=150, bbox_inches='tight')
    plt.savefig('qgt_simulation.png', dpi=150, bbox_inches='tight')
    print("\nSalvati: qgt_simulation.pdf  qgt_simulation.png")


if __name__ == '__main__':
    main()
