#!/usr/bin/env bash
# QGT formal pilot — audit gate. Fails on any forbidden shortcut.
set -euo pipefail
cd "$(dirname "$0")/.."
echo "== forbidden shortcuts =="
if grep -RnE '\bsorry\b|\badmit\b|\bunsafe\b|\bnative_decide\b' QGT --include=*.lean \
   | grep -v '^QGT/Audit/' ; then
  echo "AUDIT FAILED: forbidden shortcut present"; exit 1
fi
echo "  none found"
echo "== axioms of every exported theorem =="
env LEAN_PATH=.lake/build/lib/lean lean QGT/Audit/PrintAxioms.lean
