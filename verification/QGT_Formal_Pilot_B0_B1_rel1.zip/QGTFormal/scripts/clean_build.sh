#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
rm -rf .lake/build
lake build
bash scripts/audit.sh
