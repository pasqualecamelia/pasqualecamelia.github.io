# Source alignment

## Ambiguities encountered, and the interpretation chosen

**1. Carrier of the arithmetic.** Appendix L writes in `Z[sqrt5]` and evaluates
into the reals. The pilot's environment has no mathlib, so `Real.sqrt` is
unavailable. Chosen interpretation: prove every identity inside the ring of
integers of Q(sqrt 5), the weakest faithful reading. No claim about `Real` is
made. This is a deviation of carrier, not of content: `70 + 30 sqrt5`,
`M_Pi`, the Fibonacci norm and `20 phi^4` all live in that ring.

**2. Normalisation of the chiral form.** `C_chi = (1/2)[[0,1],[1,0]]` needs a
division the carrier does not have. Chosen interpretation: the scaled identity,
with the halving left to any ring where 2 is invertible. Declared, not hidden.

**3. `phi + phi^{-1}`.** The inverse is not primitive in `Zphi`. Chosen
interpretation: prove `phi * (phi - 1) = 1` first, so that `phi - 1` is
*shown* to be the inverse, then `phi + (phi-1) = sqrt5`. Nothing is assumed.

**4. Readings not formalized.** I.2, I.3, III.1 and III.3 need analytic or real
structure — singular values, `log phi`, `pi`, square roots of non-integers.
They are outside the pilot's carrier and are omitted rather than approximated.
`SOURCE_MAP.md` records them as not formalized. Omitting them is the
conservative choice: a decimal-level check would not be a proof.

## Mismatches between the Python harness and the monograph

None found. Every identity the harness certifies symbolically and that the
pilot re-proves in Lean agrees with the printed source.

## Status

No blocking ambiguity. The pilot's scope is narrower than Appendix L, and the
narrowing is declared everywhere it occurs.
