import numpy as np, json
from pathlib import Path

BASE = Path(__file__).resolve().parent
OUT = BASE / "results"
OUT.mkdir(exist_ok=True)

def H2():
    return np.array([[1,1],[1,-1]], dtype=complex)/np.sqrt(2)

def Jphi(phi):
    return np.array([[0, np.exp(-1j*phi)],
                     [np.exp(1j*phi), 0]], dtype=complex)

def Uphi(phi):
    return H2() @ np.diag([1, np.exp(-1j*phi)])

def walsh4(vals):
    W = np.array([[1,1,1,1],
                  [1,1,-1,-1],
                  [1,-1,1,-1],
                  [1,-1,-1,1]], dtype=float)
    return 0.25*W@np.asarray(vals, dtype=float)

rng = np.random.default_rng(20261025)
max_diag_err = 0.0
max_unit_err = 0.0
max_prob_err = 0.0

for phi in np.linspace(-np.pi, np.pi, 257):
    J = Jphi(phi)
    U = Uphi(phi)
    max_unit_err = max(max_unit_err, np.linalg.norm(U.conj().T@U-np.eye(2)))
    max_diag_err = max(max_diag_err, np.linalg.norm(U@J@U.conj().T-np.diag([1,-1])))
    for _ in range(5):
        z = rng.normal(size=2)+1j*rng.normal(size=2)
        z /= np.linalg.norm(z)
        p = np.abs(U@z)**2
        Pp = (np.eye(2)+J)/2
        Pm = (np.eye(2)-J)/2
        pd = np.array([np.real(z.conj()@Pp@z), np.real(z.conj()@Pm@z)])
        max_prob_err = max(max_prob_err, np.max(np.abs(p-pd)))

# Uniqueness family: output phases and output-label permutation are the only freedoms
max_unique_err = 0.0
for phi in np.linspace(-2.7,2.7,31):
    U0 = Uphi(phi)
    for _ in range(20):
        a,b = rng.uniform(-np.pi,np.pi,2)
        D = np.diag(np.exp(1j*np.array([a,b])))
        perm = np.eye(2) if rng.integers(2)==0 else np.array([[0,1],[1,0]])
        U = D@perm@U0
        target = perm@np.diag([1,-1])@perm.T
        max_unique_err = max(max_unique_err, np.linalg.norm(U@Jphi(phi)@U.conj().T-target))

# Walsh coefficient recovery
max_walsh_err = 0.0
for _ in range(10000):
    f00,f10,f01,f11 = rng.normal(size=4)
    vals=[]
    for s1,s2 in [(1,1),(1,-1),(-1,1),(-1,-1)]:
        vals.append(f00+f10*s1+f01*s2+f11*s1*s2)
    coeffs=walsh4(vals)
    max_walsh_err=max(max_walsh_err,np.max(np.abs(coeffs-[f00,f10,f01,f11])))

# Mixed finite difference -> mixed Hessian
def F(x,y):
    return 1.7 + 0.3*x - 0.8*y + 2.25*x*y + 0.4*x*x - 0.2*y*y + 0.7*x*x*y - 0.5*x*y*y

true_mixed = 2.25
eps_list = np.array([0.2,0.1,0.05,0.025,0.0125])
fd=[]
for e in eps_list:
    v=(F(e,e)-F(e,-e)-F(-e,e)+F(-e,-e))/(4*e*e)
    fd.append(v)

summary = {
    "theorem_class": [
        "two orthonormal coherent branches",
        "unitary involutive exchange",
        "lossless local carrier",
        "parity-resolving projective readout"
    ],
    "max_unitarity_error": float(max_unit_err),
    "max_diagonalization_error": float(max_diag_err),
    "max_probability_projection_error": float(max_prob_err),
    "max_uniqueness_family_error": float(max_unique_err),
    "max_walsh_coefficient_recovery_error": float(max_walsh_err),
    "mixed_hessian_test": {
        "true": true_mixed,
        "eps": eps_list.tolist(),
        "finite_difference": [float(x) for x in fd],
        "errors": [float(abs(x-true_mixed)) for x in fd]
    },
    "verdict": "PASS_MINIMAL_COHERENT_TWO_WAY_READOUT"
}
(OUT/"verification_summary.json").write_text(json.dumps(summary,indent=2), encoding="utf-8")
print(json.dumps(summary,indent=2))
