# QGT Minimal Qubit–Hadamard Closure r01

Run:

```bash
python verify_minimal_qubit_hadamard.py
```

Expected verdict:

`PASS_MINIMAL_COHERENT_TWO_WAY_READOUT`

Contents:
- `THEOREM.md`
- `verify_minimal_qubit_hadamard.py`
- `results/verification_summary.json`
- `MANIFEST_SHA256.json`
