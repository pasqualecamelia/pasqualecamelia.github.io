/-
QGT Formal Pilot — B0: the minimal upstream contract.

This module does NOT prove the rank-selection theorem. It states, as an
explicit and named import, what B1 consumes from upstream. Every B1 theorem
that depends on the rank takes this contract as a hypothesis, so the
dependency is visible in the theorem signature and cannot be hidden.

  B1 consumes the rank-five selection; it does not re-prove its uniqueness.
-/
import QGT.Foundations.Fibonacci

namespace QGT

/-- The upstream selection data imported by B1. Each field names one input.
    No field carries a conclusion of any B1 theorem. -/
structure RankSelection where
  /-- the selected rank of the observable projection -/
  rank : Nat
  /-- the selection theorem fixes the rank to five -/
  rank_is_five : rank = 5
  /-- the coefficient vector of the kernel arithmetic is the Fibonacci pair -/
  coeff_hi : Int
  coeff_lo : Int
  coeff_is_fib : coeff_hi = fib 5 ∧ coeff_lo = fib 4

/-- The canonical instance of the contract, as imported from the monograph. -/
def upstream : RankSelection :=
  { rank := 5, rank_is_five := rfl,
    coeff_hi := fib 5, coeff_lo := fib 4,
    coeff_is_fib := ⟨rfl, rfl⟩ }

theorem upstream_rank : upstream.rank = 5 := upstream.rank_is_five

theorem upstream_coeffs : upstream.coeff_hi = 5 ∧ upstream.coeff_lo = 3 := by
  constructor <;> decide

end QGT
