# Source map

The reproducibility calculation is downstream of the following QGT structures already present in the corpus:

1. **FIELD finite-access action descent** — Schur/Pfaffian effective action; first and second response jets; complete Hessian with propagation and contact/seagull terms; moving-access terms included in the physical jet.
2. **MATTER finite-access** — dressed poles, readable residues and the requirement that a physical transition be both spectrally persistent and visible in a preparation/detector channel.
3. **CELL / same-parent descent** — FIELD and MATTER as two descendants of one parent; electromagnetic strength from the massless-pole residue; atomic dipole as a coherence and Ramsey/Raman phase-to-population conversion.
4. **Dynamical Readout in the Fibonacci–Mellin Transform** — Hadamard readout of the two-sheet doublet and projective phase matching.
5. **Two Fibonacci Butterflies** — explicit local Hadamard/Stokes parity channels `c_±=(L±H)/sqrt(2)` and the warning that this is not a global radix-2 factorization of the full FMT.
6. **Spinorial Sheet Transport** — exact local two-channel lossless butterfly and Hadamard-conjugated SU(2) transport.

The present r01 adds only the following new executable bridge:

`same Schrödinger-grade H[E] -> four sign evolutions -> Walsh 11 phase beta_11 -> static/dynamic cross-check`.

It does **not** promote the upstream microscopic parent-normalization gate to closed status.
