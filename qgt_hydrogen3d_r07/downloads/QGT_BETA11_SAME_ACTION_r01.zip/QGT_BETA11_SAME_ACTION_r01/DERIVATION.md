# beta_11 derivation ledger

## 1. One effective action
At Schrödinger grade the atomic sector is represented by

`H[E](t)=H0-E(t)z`, `H0=-1/2 nabla^2-1/r`.

The same background variable `E` therefore changes the same atomic operator whose unperturbed poles define the bound states.

## 2. Two independent binary controls
Let

`E_br(t) = b eps1 f1(t) + r eps2 f2(t)`, with `b,r in {+1,-1}`.

For each sign pair calculate the full unitary `U_br` and an interferometric/survival amplitude

`M_br=<g|U_br|g>`.

## 3. Walsh mixed channel
The phase channel that is odd in each control separately and even under simultaneous reversal is

`beta_11 = 1/4 [beta_++ - beta_+- - beta_-+ + beta_--]`.

To avoid four independent phase unwraps, use the equivalent weak-branch ratio

`beta_11 = 1/4 Arg[(M_++ M_--)/(M_+- M_-+)]`.

## 4. Perturbative same-action form
For interaction-picture vertices `V1`, `V2` and a possible direct mixed/contact vertex `V12`, the `(1,1)` unitary coefficient is

`U11 = -(i/hbar) integral V12^I(t) dt`

`      -(1/hbar^2) integral_{t1>t2} [V1^I(t1)V2^I(t2)+V2^I(t1)V1^I(t2)] dt1 dt2.`

This is the time-domain counterpart of the complete QGT response pattern “two insertions through the retained propagator + direct contact term”.

## 5. Static limit
For a parity-even ground state the linear Stark shift vanishes and

`Delta E_g = -(1/2) alpha_g E^2 + O(E^4)`.

Substituting `E_br` gives the mixed energy coefficient

`Delta E_11(t) = -alpha_g eps1 eps2 f1(t)f2(t)`.

Hence the accumulated phase is

`beta_11 = alpha_g eps1 eps2 integral f1 f2 dt`

in scaled units (`hbar=1`). Therefore

`alpha_eff := beta_11/(eps1 eps2 I12) -> alpha_g`

for weak and adiabatic pulses.

## 6. Independent static benchmark
The radial Sternheimer solve uses

`(H_{l=1}-E_1s) u1 = (r/sqrt(3)) u_1s`

and

`alpha_1s = (2/sqrt(3)) integral u_1s(r) r u1(r) dr`.

It converges to `9/2` without using the four-sign dynamics.

## 7. QGT status firewall
The parent FIELD construction requires the complete response, including moving-access and contact terms when present. The present length-gauge Coulomb witness is the downstream Schrödinger-grade realization in which the electric-dipole interaction is explicit. It therefore tests the **form and operational extraction** of beta_11, but does not prove the still-open microscopic ownership and absolute normalization of that dipole vertex by the QGT parent.
