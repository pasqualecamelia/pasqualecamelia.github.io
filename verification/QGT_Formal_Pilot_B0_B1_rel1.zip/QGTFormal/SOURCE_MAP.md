# Source map — Lean theorem to frozen monograph

Authority: QGT First Edition v7.6.6, Appendix L, *The Projection Constant*, pp. 529-537
(`\label{app:alpha_structure}`).

| Lean theorem | Reading | Source tag | Source statement | Formalized statement | Status |
|---|---|---|---|---|---|
| `chiral_contraction` | I.1 | `(I.1)` | `alpha_Pi^-1 = q^T C_chi q = xi eta` | `q^T [[0,1],[1,0]] q = 2(xi eta)` | scaled, declared |
| `Zphi.phi_sq` | — | Foundations | `phi^2 = phi + 1` | identical | exact |
| `Zphi.sqrt5_sq` | — | Foundations | `(sqrt5)^2 = 5` | identical | exact |
| `Zphi.phi_add_inv` | I.4 | text | `kappa = phi + phi^-1 = sqrt5` | `phi + (phi-1) = sqrt5`, with `phi(phi-1)=1` | exact |
| `pincherleReadout` | I.4 | `(I.4)` | `alpha_Pi^-1 = Lambda_Pi^2 = 20 phi^4` | identical in `Zphi` | exact |
| `LambdaPi_alt` | I.4 | text | `Lambda_Pi = 5 + 3 sqrt5` | identical | exact |
| `fibonacciNormReadout` | II.1 | `(II.1)`, `eq:R5` | `alpha_Pi^-1 = c_F^T G c_F` | identical, contract-parametrised | exact |
| `fibonacciNorm_surd` | II.1 | `(II.1)` | `= 70 + 30 sqrt5` | identical | exact |
| `MPi_val`, `MPi_trace`, `MPi_det_val` | II.2 | `(II.2)`, `eq:R6` | `M_Pi = [[5,15],[3,5]]`, tr 10, det -20 | identical | exact |
| `MPi_sq_val`, `MPi_sq_regular` | II.2 | `(II.2)` | `M_Pi^2 = [[70,150],[30,70]] = reg(70+30 sqrt5)` | identical | exact |
| `regularMatrixReadout` | II.2 | `(II.2)` | `alpha_Pi^-1 = eval_sqrt5(M_Pi^2)` | identical | exact |
| `rho_mul` | II.2 | text | regular representation is multiplicative | identical | exact |
| `crossRepresentation` | I.4/II.1/II.2 | convergence section | one identity, three origins | conjunction of the three equalities | exact |
| `fib_sum_five_six` | III.2 | `(III.2)` | `B13 = S5 + T8` | `F_5 + F_6 = F_7` | exact |
| `finiteRankSensitivity` | — | not in source | — | finite sensitivity over r in {3,4,5,6,7} | new, declared as control |

Readings I.2 (SVD boundary metric), I.3 (transfer filter) and III.3 (FMT zero
mode) are **not** formalized here: they require real or analytic structure.
They remain covered by the Python harness at its lower assurance level.
Reading III.1 (anisotropy 11/5) is likewise not formalized in the pilot.
