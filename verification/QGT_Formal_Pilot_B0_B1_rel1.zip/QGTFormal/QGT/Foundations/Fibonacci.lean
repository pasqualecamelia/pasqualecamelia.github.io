/-
QGT Formal Pilot — Foundations: Fibonacci numbers.
F_4 = 3 and F_5 = 5 are DERIVED from the recursion, not hardcoded.
-/
namespace QGT

def fib : Nat → Int
  | 0     => 0
  | 1     => 1
  | n + 2 => fib n + fib (n + 1)

theorem fib_four : fib 4 = 3 := by decide
theorem fib_five : fib 5 = 5 := by decide
theorem fib_six  : fib 6 = 8 := by decide
theorem fib_seven : fib 7 = 13 := by decide

/-- Boundary filter decomposition: `F_5 + F_6 = F_7`, i.e. `5 + 8 = 13`. -/
theorem fib_sum_five_six : fib 5 + fib 6 = fib 7 := by decide

end QGT
