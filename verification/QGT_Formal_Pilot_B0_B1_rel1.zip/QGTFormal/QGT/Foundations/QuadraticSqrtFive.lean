/-
QGT Formal Pilot — Foundations: the sqrt5 basis and the golden quadratic form.

Appendix L works in the basis {1, sqrt5}; the carrier of this pilot is the
basis {1, phi}. The change of basis is a definition; the shape of the result
is a theorem, obtained by unfolding, never by definition.

Named functions (`Zphi.add`, `Zphi.smul`) are used instead of the operator
instances so that `unfold` reaches the components without expanding the
typeclass machinery.
-/
import QGT.Foundations.Golden

namespace QGT
open Zphi

/-- `eval_sqrt5 (a,b) = a + b*sqrt5`, expressed in the {1, phi} basis. -/
def evalSqrt5 (a b : Int) : Zphi := Zphi.add (Zphi.ofInt a) (Zphi.smul b Zphi.sqrt5)

/-- Since `sqrt5 = 2*phi - 1`, the pair `(a,b)` maps to `(a-b, 2b)`. -/
theorem evalSqrt5_val (a b : Int) : evalSqrt5 a b = ⟨a - b, 2 * b⟩ := by
  unfold evalSqrt5 Zphi.add Zphi.ofInt Zphi.smul Zphi.sqrt5
  simp only [Zphi.mk.injEq]
  omega

/-- The golden quadratic form `c^T G c` with `G = [[1, sqrt5],[sqrt5, 5]]`,
    assembled from the entries of `G`: `a*a + 5*b*b + 2*a*b*sqrt5`. -/
def goldenNorm (a b : Int) : Zphi :=
  Zphi.add (Zphi.add (Zphi.ofInt (a * a)) (Zphi.ofInt (5 * (b * b))))
           (Zphi.smul (2 * (a * b)) Zphi.sqrt5)

/-- The components of the golden quadratic form. -/
theorem goldenNorm_val (a b : Int) :
    goldenNorm a b = ⟨a * a + 5 * (b * b) - 2 * (a * b), 4 * (a * b)⟩ := by
  unfold goldenNorm Zphi.add Zphi.ofInt Zphi.smul Zphi.sqrt5
  simp only [Zphi.mk.injEq]
  generalize a * a = A
  generalize b * b = B
  generalize a * b = C
  omega

end QGT
