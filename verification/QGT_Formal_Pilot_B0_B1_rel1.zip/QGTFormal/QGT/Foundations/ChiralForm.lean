/-
QGT Formal Pilot — Foundations: the chiral bilinear form.

The monograph's form is C_chi = (1/2) * [[0,1],[1,0]], and the certified
statement here is the monograph's own, with the halving present:

    q^T C_chi q = xi * eta.

The carrier is Rat, where 2 is invertible. No scaling, no weakening.
-/
namespace QGT

/-- The chiral form `q^T C_chi q` with `C_chi = (1/2)[[0,1],[1,0]]`,
    assembled from the entries of the matrix. -/
def chiralForm (xi eta : Rat) : Rat :=
  (1/2) * (xi * eta) + (1/2) * (eta * xi)

/-- T1: the chiral form extracts exactly the product, for all rationals. -/
theorem chiral_contraction (xi eta : Rat) : chiralForm xi eta = xi * eta := by
  unfold chiralForm
  grind

end QGT
