"""
qgt_companion — QGT Companion Simulator v2.0
The Quantum Gauge Theory of Time (Camelia, 2026)

Moduli:
  qgt_core      Costanti strutturali, breathing, solitone, CMB
  qgt_clifford  Algebra di Clifford Cl(4,1), proiettori chirali
  qgt_hydrogen  Simulazione dinamica atomo di idrogeno (ITP)
  qgt_plots     Funzioni di visualizzazione matplotlib
  qgt_verify    Verifica strutturale con livelli epistemici

Uso rapido:
  python -m qgt_companion verify
  python -m qgt_companion hydrogen
  python -m qgt_companion all --plot
"""

__version__ = "2.0.0"
__author__  = "Pasquale Camelia"
__orcid__   = "0009-0006-4779-4647"
