# Build report — QGT formal pilot

## Toolchain

| | |
|---|---|
| Lean | **4.32.1** (commit f054605a), the release carrying the kernel soundness fix of 22 July 2026 |
| mathlib | **not used** — unavailable in the environment; see the contract |
| dependencies | none; the project builds from Lean core alone |

Building from Lean core only is a property worth stating: the pilot has no
external mathematical dependency, so a referee reproduces it with the Lean
toolchain and nothing else.

## Result

```
lake build   ->   Build completed successfully
```

11 targets built. Zero errors.

## Forbidden shortcuts

```
grep -RnE '\bsorry\b|\badmit\b|\bunsafe\b|\bnative_decide\b' QGT   ->   0 matches
```

## Axioms of exported theorems

```
QGT.chiral_contraction            [propext, Classical.choice, Quot.sound]
QGT.Zphi.phi_sq                   no axioms
QGT.Zphi.sqrt5_sq                 no axioms
QGT.Zphi.phi_inv                  no axioms
QGT.Zphi.phi_add_inv              no axioms
QGT.fib_five                      no axioms
QGT.Zphi.add_comm                 [propext, Classical.choice, Quot.sound]
QGT.Zphi.add_assoc                [propext, Classical.choice, Quot.sound]
QGT.Zphi.mul_comm                 [propext, Classical.choice, Quot.sound]
QGT.Zphi.mul_assoc                [propext, Classical.choice, Quot.sound]
QGT.Zphi.left_distrib             [propext, Classical.choice, Quot.sound]
QGT.pincherleReadout              no axioms
QGT.fibonacciNormReadout          no axioms
QGT.regularMatrixReadout          no axioms
QGT.regularMatrixReadout_concrete no axioms
QGT.MPi_sq_regular                no axioms
QGT.rho_mul                       [propext]
QGT.crossRepresentation           no axioms
QGT.finiteRankSensitivity         no axioms
```

The five B1 results and the arithmetic foundations depend on **no axioms at
all**: they are closed computations checked by the kernel. The ring laws and
the chiral contraction use the three standard logical axioms of Lean, drawn in
by `grind`. No custom axiom exists in the project and none carries a QGT
conclusion.

## Independent proof-term check — NOT ESTABLISHED

`leanchecker` ships with the 4.32.1 toolchain and returns 0 on this project.
That result is **not reported as a verification**, because the same command
also returns 0 after 4 KB of a compiled `.olean` is overwritten with garbage.
A check that does not fail on a corrupted artefact does not certify an intact
one. Until the checker is invoked in a way that demonstrably discriminates,
this requirement stays open.

## Status

**PASS as a formalization pilot**, with the deviations declared in
`FORMALIZATION_CONTRACT.md`: the carrier is `Z[phi]` rather than `Real`, and
the optional extensions E1 and E2 are omitted. T1 is no longer weakened: it is
proved over `Rat` in the monograph's own normalisation.

**NOT a high-assurance certificate**, for one reason only: the independent
proof-term check above is not established.
