/-
QGT Formal Pilot — audit: axiom dependencies of every exported theorem.
-/
import QGT.Foundations.ChiralForm
import QGT.B1.Readouts
import QGT.B1.NegativeControls

-- foundations
#print axioms QGT.chiral_contraction
#print axioms QGT.Zphi.phi_sq
#print axioms QGT.Zphi.sqrt5_sq
#print axioms QGT.Zphi.phi_inv
#print axioms QGT.Zphi.phi_add_inv
#print axioms QGT.fib_five
-- commutative ring laws of the carrier
#print axioms QGT.Zphi.add_comm
#print axioms QGT.Zphi.add_assoc
#print axioms QGT.Zphi.mul_comm
#print axioms QGT.Zphi.mul_assoc
#print axioms QGT.Zphi.left_distrib
-- B1 theorems
#print axioms QGT.pincherleReadout
#print axioms QGT.fibonacciNormReadout
#print axioms QGT.regularMatrixReadout
#print axioms QGT.regularMatrixReadout_concrete
#print axioms QGT.MPi_sq_regular
#print axioms QGT.rho_mul
#print axioms QGT.crossRepresentation
#print axioms QGT.finiteRankSensitivity
