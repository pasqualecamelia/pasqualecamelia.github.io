/-
QGT Formal Pilot — Foundations: the regular representation of Z[sqrt5].

rho(a,b) = [[a, 5b],[b, a]] acting on the basis {1, sqrt5}. The multiplication
law and the evaluation compatibility are theorems.
-/
import QGT.Foundations.Golden
import QGT.Foundations.QuadraticSqrtFive

namespace QGT

/-- A 2x2 integer matrix. -/
structure Mat2 where
  m00 : Int
  m01 : Int
  m10 : Int
  m11 : Int
deriving DecidableEq, Repr

namespace Mat2

def mul (x y : Mat2) : Mat2 :=
  ⟨x.m00 * y.m00 + x.m01 * y.m10, x.m00 * y.m01 + x.m01 * y.m11,
   x.m10 * y.m00 + x.m11 * y.m10, x.m10 * y.m01 + x.m11 * y.m11⟩

def trace (x : Mat2) : Int := x.m00 + x.m11
def det (x : Mat2) : Int := x.m00 * x.m11 - x.m01 * x.m10

end Mat2

/-- Regular representation of `a + b*sqrt5`. -/
def rho (a b : Int) : Mat2 := ⟨a, 5 * b, b, a⟩

/-- The representation is multiplicative: rho(a,b) rho(c,d) = rho(ac+5bd, ad+bc). -/
theorem rho_mul (a b c d : Int) :
    Mat2.mul (rho a b) (rho c d) = rho (a * c + 5 * (b * d)) (a * d + b * c) := by
  unfold rho Mat2.mul
  simp only [Mat2.mk.injEq]
  refine ⟨?_, ?_, ?_, ?_⟩ <;>
    simp [Int.mul_assoc, Int.mul_comm, Int.mul_left_comm, Int.add_mul,
          Int.mul_add, Int.add_comm, Int.add_left_comm]

/-- A matrix is in the image of rho exactly when it has the (a, 5b; b, a) shape. -/
def isRegular (M : Mat2) : Prop := M.m01 = 5 * M.m10 ∧ M.m11 = M.m00

instance (M : Mat2) : Decidable (isRegular M) := by
  unfold isRegular; infer_instance

end QGT
