#!/usr/bin/env python3
"""QGT beta_11 same-effective-action reproducibility witness.

Scope
-----
This script works in the dimensionless Schrödinger-grade QGT hydrogen sector

    H[E](t) = H0 - E(t) z,
    H0 = -1/2 nabla^2 - 1/r,

and extracts the mixed two-control phase channel

    beta11 = 1/4 (beta++ - beta+- - beta-+ + beta--)

from four real-time evolutions.  A branch-robust form is used:

    beta11 = 1/4 Arg[(M++ M--)/(M+- M-+)],

where M_br = <1s|U_br|1s> and the continuous weak-response branch is chosen.

The static benchmark is computed independently from the same Coulomb Hamiltonian
by a radial Sternheimer solve.  The dynamic calculation uses a partial-wave TDSE
with Crank-Nicolson half-steps for H0 and an exact local exponential for -E(t)z.

Epistemic scope
---------------
This closes a SAME EFFECTIVE ACTION witness at Schrödinger grade.  It does NOT
by itself derive the absolute electromagnetic normalization or the physical
response jet from the microscopic QGT parent.  Those remain the upstream
same-parent ownership/normalization gate.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)


def radial_sternheimer_alpha(dr: float = 0.005, rmax: float = 60.0) -> float:
    """Static 1s polarizability from (H_l=1-E_1) u1 = (r/sqrt(3)) u_1s."""
    r = np.arange(dr, rmax, dr)
    n = r.size
    # Reduced radial Hamiltonian H_l = -1/2 d2/dr2 + l(l+1)/(2r2) - 1/r, l=1.
    diag = 1.0 / dr**2 + 1.0 / r**2 - 1.0 / r + 0.5  # subtract E1=-1/2
    off = np.full(n - 1, -0.5 / dr**2)
    A = sp.diags([off, diag, off], [-1, 0, 1], format="csc")

    u0 = 2.0 * r * np.exp(-r)
    u0 /= math.sqrt(float(np.sum(u0 * u0) * dr))
    source = (r / math.sqrt(3.0)) * u0
    u1 = spla.spsolve(A, source)
    alpha = 2.0 / math.sqrt(3.0) * float(np.sum(u0 * r * u1) * dr)
    return alpha


@dataclass
class RunResult:
    b: int
    rsign: int
    amplitude_real: float
    amplitude_imag: float
    amplitude_abs: float
    phase: float
    norm_drift: float
    excited_weight: float

    @property
    def amplitude(self) -> complex:
        return complex(self.amplitude_real, self.amplitude_imag)


class PartialWaveHydrogen:
    """m=0 partial-wave solver for H(t)=H0-E(t) z in atomic/QGT scaled units."""

    def __init__(self, dr=0.05, rmax=50.0, lmax=2, dt=0.05):
        self.dr = float(dr)
        self.rmax = float(rmax)
        self.lmax = int(lmax)
        self.dt = float(dt)
        self.r = np.arange(self.dr, self.rmax, self.dr)
        n = self.r.size

        self.H = []
        self.lu = []
        self.B = []
        for ell in range(self.lmax + 1):
            diag = (
                1.0 / self.dr**2
                + ell * (ell + 1) / (2.0 * self.r**2)
                - 1.0 / self.r
            )
            off = np.full(n - 1, -0.5 / self.dr**2)
            H = sp.diags([off, diag, off], [-1, 0, 1], format="csc")
            self.H.append(H)
            # CN half-step: exp(-i H dt/2) approximated by Cayley with h=dt/2.
            A = sp.eye(n, format="csc") + 1j * (self.dt / 4.0) * H
            B = sp.eye(n, format="csc") - 1j * (self.dt / 4.0) * H
            self.lu.append(spla.splu(A))
            self.B.append(B)

        # cos(theta) in the Y_l0 basis; z = r cos(theta).
        C = np.zeros((self.lmax + 1, self.lmax + 1))
        for ell in range(self.lmax):
            c = (ell + 1) / math.sqrt((2 * ell + 1) * (2 * ell + 3))
            C[ell, ell + 1] = C[ell + 1, ell] = c
        self.C = C
        self.c_eval, self.c_vec = np.linalg.eigh(C)

        # Numerical 1s eigenstate of the SAME radial H0 discretization.
        evals, vecs = spla.eigsh(self.H[0], k=1, which="SA")
        self.E0 = float(evals[0])
        u0 = vecs[:, 0].real
        u0 /= math.sqrt(float(np.sum(u0 * u0) * self.dr))
        if u0[np.argmax(np.abs(u0))] < 0:
            u0 *= -1
        self.u0 = u0

    def _h0_half(self, psi: np.ndarray) -> np.ndarray:
        out = np.empty_like(psi)
        for ell in range(self.lmax + 1):
            out[ell] = self.lu[ell].solve(self.B[ell].dot(psi[ell]))
        return out

    def _field_step(self, psi: np.ndarray, field: float) -> np.ndarray:
        # exp[-i (-E z) dt] = exp[+i E r C dt].  Diagonalize C once.
        tmp = self.c_vec.T @ psi
        tmp *= np.exp(
            1j
            * field
            * self.c_eval[:, None]
            * self.r[None, :]
            * self.dt
        )
        return self.c_vec @ tmp

    @staticmethod
    def _sin2(t: float, T: float, delay: float) -> float:
        x = (t - delay) / T
        if x < 0.0 or x > 1.0:
            return 0.0
        return math.sin(math.pi * x) ** 2

    def four_sign(self, T=120.0, delay=15.0, eps1=0.0025, eps2=None):
        if eps2 is None:
            eps2 = eps1
        total = max(T, delay + T)
        nsteps = int(round(total / self.dt))
        tmid = (np.arange(nsteps) + 0.5) * self.dt
        f1 = np.array([self._sin2(float(t), T, 0.0) for t in tmid])
        f2 = np.array([self._sin2(float(t), T, delay) for t in tmid])
        I12 = float(np.sum(f1 * f2) * self.dt)

        runs: dict[tuple[int, int], RunResult] = {}
        for b in (+1, -1):
            for rr in (+1, -1):
                psi = np.zeros((self.lmax + 1, self.r.size), dtype=complex)
                psi[0] = self.u0
                max_drift = 0.0
                for k in range(nsteps):
                    field = eps1 * b * f1[k] + eps2 * rr * f2[k]
                    psi = self._h0_half(psi)
                    psi = self._field_step(psi, float(field))
                    psi = self._h0_half(psi)
                    norm = float(np.sum(np.abs(psi) ** 2) * self.dr)
                    max_drift = max(max_drift, abs(norm - 1.0))

                M = complex(np.vdot(self.u0, psi[0]) * self.dr)
                excited = float(np.sum(np.abs(psi[1:]) ** 2) * self.dr)
                runs[(b, rr)] = RunResult(
                    b=b,
                    rsign=rr,
                    amplitude_real=float(M.real),
                    amplitude_imag=float(M.imag),
                    amplitude_abs=float(abs(M)),
                    phase=float(np.angle(M)),
                    norm_drift=max_drift,
                    excited_weight=excited,
                )

        Mpp = runs[(+1, +1)].amplitude
        Mpm = runs[(+1, -1)].amplitude
        Mmp = runs[(-1, +1)].amplitude
        Mmm = runs[(-1, -1)].amplitude

        # Branch-robust parity ratio.  In the weak regime its principal argument is continuous.
        parity_ratio = Mpp * Mmm / (Mpm * Mmp)
        beta11 = 0.25 * float(np.angle(parity_ratio))
        alpha_eff = (
            beta11 / (eps1 * eps2 * I12)
            if abs(eps1 * eps2 * I12) > 0
            else float("nan")
        )
        return {
            "T": float(T),
            "delay": float(delay),
            "eps1": float(eps1),
            "eps2": float(eps2),
            "I12": I12,
            "beta11": beta11,
            "alpha_eff": float(alpha_eff),
            "parity_ratio_real": float(parity_ratio.real),
            "parity_ratio_imag": float(parity_ratio.imag),
            "runs": [runs[k].__dict__ for k in [(+1,+1),(+1,-1),(-1,+1),(-1,-1)]],
            "max_norm_drift": max(v.norm_drift for v in runs.values()),
            "max_excited_weight": max(v.excited_weight for v in runs.values()),
        }


def write_csv(path: Path, rows: list[dict], fields: list[str]):
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for row in rows:
            w.writerow({k: row.get(k) for k in fields})


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def run(full=False):
    # Workstream 1: independent static Hessian/polarizability benchmark.
    static_rows = []
    for dr in [0.04, 0.02, 0.01, 0.005]:
        static_rows.append({"dr": dr, "alpha_1s": radial_sternheimer_alpha(dr=dr)})
    alpha_ref = static_rows[-1]["alpha_1s"]

    # Workstream 2: dynamic four-sign evolution in the same effective action.
    solver = PartialWaveHydrogen(dr=0.05, rmax=50.0, lmax=2, dt=0.05)
    T_list = [40.0, 60.0, 80.0, 120.0, 160.0] if full else [80.0, 120.0, 160.0]
    conv = []
    for T in T_list:
        row = solver.four_sign(T=T, delay=T/8.0, eps1=0.0025)
        conv.append({
            "T": T,
            "delay": T/8.0,
            "I12": row["I12"],
            "beta11": row["beta11"],
            "alpha_eff": row["alpha_eff"],
            "rel_error_vs_4p5": row["alpha_eff"]/4.5 - 1.0,
            "max_norm_drift": row["max_norm_drift"],
            "max_excited_weight": row["max_excited_weight"],
        })

    # Extrapolate leading adiabatic correction ~ 1/T^2.
    x = np.array([1.0/(r["T"]**2) for r in conv])
    y = np.array([r["alpha_eff"] for r in conv])
    slope, intercept = np.polyfit(x, y, 1)

    # Frozen reference four-sign run: reuse T=160 convergence result when available.
    ref = solver.four_sign(T=160.0, delay=20.0, eps1=0.0025) if full else solver.four_sign(T=160.0, delay=20.0, eps1=0.0025)

    # Workstream 3: red-team controls.
    amp_values = [0.0015, 0.0020, 0.0025, 0.0030] if full else [0.0015, 0.0025, 0.0030]
    amp_rows = []
    for eps in amp_values:
        rr = solver.four_sign(T=120.0, delay=15.0, eps1=eps)
        amp_rows.append({
            "eps": eps,
            "beta11": rr["beta11"],
            "beta11_over_eps2": rr["beta11"]/(eps*eps),
            "alpha_eff": rr["alpha_eff"],
        })

    no_overlap = solver.four_sign(T=80.0, delay=100.0, eps1=0.0025)

    # Controls evaluated without tuning after the fact.
    amp_alpha = np.array([r["alpha_eff"] for r in amp_rows])
    controls = {
        "no_overlap_I12": no_overlap["I12"],
        "no_overlap_beta11_rad": no_overlap["beta11"],
        "no_overlap_pass_abs_beta_lt_1e-7": abs(no_overlap["beta11"]) < 1e-7,
        "weak_amplitude_alpha_eff_mean": float(amp_alpha.mean()),
        "weak_amplitude_alpha_eff_rel_spread": float((amp_alpha.max()-amp_alpha.min())/amp_alpha.mean()),
        "bilinear_scaling_pass_rel_spread_lt_1e-3": float((amp_alpha.max()-amp_alpha.min())/amp_alpha.mean()) < 1e-3,
        "norm_conservation_pass_lt_1e-10": ref["max_norm_drift"] < 1e-10,
        "weak_excitation_pass_lt_1e-6": ref["max_excited_weight"] < 1e-6,
    }

    summary = {
        "status": {
            "beta11_identity": "CLOSED: Walsh/Hadamard (1,1) mixed channel",
            "same_effective_action_schrodinger_grade": "PASS computational witness",
            "same_microscopic_QGT_parent_normalization": "OPEN upstream gate",
        },
        "model": {
            "H0": "-1/2 nabla^2 - 1/r",
            "interaction": "-E(t) z",
            "units": "dimensionless QGT/atomic Coulomb units",
            "radial_solver": {"dr": solver.dr, "rmax": solver.rmax, "lmax": solver.lmax, "dt": solver.dt},
            "ground_energy_numeric": solver.E0,
        },
        "static": {
            "alpha_convergence": static_rows,
            "alpha_reference_dr_0p005": alpha_ref,
            "exact_schrodinger_alpha": 4.5,
            "reference_rel_error": alpha_ref/4.5 - 1.0,
        },
        "dynamic": {
            "convergence": conv,
            "fit_model": "alpha_eff(T) = alpha_inf + c/T^2",
            "fit_alpha_inf": float(intercept),
            "fit_c": float(slope),
            "fit_rel_error_vs_4p5": float(intercept/4.5 - 1.0),
            "reference_run": ref,
        },
        "red_team": {
            "amplitude_scaling": amp_rows,
            "no_overlap": no_overlap,
            "controls": controls,
        },
        "definitions": {
            "beta11": "1/4 Arg[(M++ M--)/(M+- M-+)] on the continuous weak-response branch",
            "alpha_eff": "beta11/(eps1 eps2 integral f1 f2 dt)",
            "pulse": "sin^2 envelopes; f2 delayed relative to f1",
        },
        "epistemic_firewall": [
            "The computation derives beta11 inside one Schrödinger-grade effective Hamiltonian H[E].",
            "It does not by itself derive the absolute electromagnetic field/charge normalization from the microscopic QGT parent.",
            "The length-gauge dipole Hamiltonian has no explicit E^2 seagull; the parent FIELD Hessian must retain contact terms in representations where they are present.",
            "The four-sign phase is an operational contraction of the mixed response, not the response tensor itself.",
        ],
    }

    (RESULTS / "beta11_summary.json").write_text(json.dumps(summary, indent=2))
    write_csv(
        RESULTS / "static_alpha_convergence.csv",
        static_rows,
        ["dr", "alpha_1s"],
    )
    write_csv(
        RESULTS / "dynamic_T_convergence.csv",
        conv,
        ["T", "delay", "I12", "beta11", "alpha_eff", "rel_error_vs_4p5", "max_norm_drift", "max_excited_weight"],
    )
    write_csv(
        RESULTS / "amplitude_scaling.csv",
        amp_rows,
        ["eps", "beta11", "beta11_over_eps2", "alpha_eff"],
    )
    write_csv(
        RESULTS / "reference_four_sign.csv",
        ref["runs"],
        ["b", "rsign", "amplitude_real", "amplitude_imag", "amplitude_abs", "phase", "norm_drift", "excited_weight"],
    )
    (RESULTS / "red_team_controls.json").write_text(json.dumps(controls, indent=2))

    # Plots are explanatory, not evidence.
    try:
        import matplotlib.pyplot as plt

        plt.figure(figsize=(7.2, 4.5))
        plt.plot([r["T"] for r in conv], [r["alpha_eff"] for r in conv], "o-")
        plt.axhline(4.5, linestyle="--", label="Schrodinger 1s: 4.5")
        plt.xlabel("pulse duration T [scaled units]")
        plt.ylabel("alpha_eff from beta11")
        plt.legend()
        plt.tight_layout()
        plt.savefig(RESULTS / "dynamic_convergence.png", dpi=180)
        plt.close()

        plt.figure(figsize=(7.2, 4.5))
        plt.plot([r["eps"]**2 for r in amp_rows], [r["beta11"] for r in amp_rows], "o-")
        plt.xlabel("epsilon^2")
        plt.ylabel("beta11 [rad]")
        plt.tight_layout()
        plt.savefig(RESULTS / "bilinear_scaling.png", dpi=180)
        plt.close()
    except Exception as exc:
        (RESULTS / "plot_warning.txt").write_text(str(exc))

    return summary


def make_manifest():
    files = []
    for p in sorted(ROOT.rglob("*")):
        if p.is_file() and p.name != "MANIFEST.sha256.json":
            files.append({"path": str(p.relative_to(ROOT)), "sha256": sha256(p), "bytes": p.stat().st_size})
    manifest = {"algorithm": "SHA-256", "files": files}
    (ROOT / "MANIFEST.sha256.json").write_text(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--full", action="store_true", help="extended convergence/amplitude sweep")
    args = ap.parse_args()
    s = run(full=args.full)
    make_manifest()
    print(json.dumps({
        "static_alpha": s["static"]["alpha_reference_dr_0p005"],
        "dynamic_alpha_inf": s["dynamic"]["fit_alpha_inf"],
        "reference_beta11": s["dynamic"]["reference_run"]["beta11"],
        "reference_alpha_eff": s["dynamic"]["reference_run"]["alpha_eff"],
        "controls": s["red_team"]["controls"],
    }, indent=2))
