# Adversarial self-audit

Performed after the build succeeded. The project is not approved merely
because it compiles.

| # | Attack | Finding |
|---|---|---|
| 1 | conclusions hidden in definitions | **clean.** `twentyPhiFour` is `smul 20 (phi^4)`; its value `⟨40,60⟩` is the theorem `twentyPhiFour_val`. `goldenNorm` is assembled from the entries of `G`. `LambdaPi` is `2 phi^2 sqrt5`, not its square. |
| 2 | target equalities imported as hypotheses | **clean.** `RankSelection` carries only the rank and the coefficient pair. No field asserts any readout value. |
| 3 | circular theorem dependencies | **clean.** Import graph is a DAG: Foundations → B0 → B1. `NegativeControls` imports `Readouts` and nothing imports it back. |
| 4 | rank five silently hardcoded in a theorem claimed general | **finding, declared.** `MPi` is built from `fib 5`/`fib 4` directly, so `regularMatrixReadout` is a statement about the concrete matrix, not a contract-parametrised one. `fibonacciNormReadout` and `crossRepresentation` do carry the contract. Recorded in the contract, item 2 of the declared weakenings. |
| 5 | a matrix diagonalized before an alleged spectral proof | **not applicable.** No spectral theorem is claimed; the SVD reading is not formalized. |
| 6 | decimal or floating-point equality used as proof | **clean.** No `Float` anywhere; the carrier is `Int` pairs and every certificate is decidable equality checked by the kernel. |
| 7 | statements weakened relative to the monograph | **one, declared.** T1 is the scaled chiral identity, since the carrier has no division. Recorded in the contract, item 1. |
| 8 | statements strengthened beyond the monograph | **clean.** No theorem claims more than its source line. `finiteRankSensitivity` is explicitly finite and is labelled a control, not a uniqueness theorem. |
| 9 | theorem names overclaiming physical meaning | **clean.** No theorem name mentions alpha, the fine-structure constant, or physics. |
| 10 | jump from mathematical equality to physical validation | **clean.** No such claim appears in any module, report, or docstring. |

## Residual risk

The correspondence between the printed statements of Appendix L and their Lean
transcription is human work. The kernel guarantees that the Lean statements are
proved; it cannot guarantee that they are the statements the monograph makes.
`SOURCE_MAP.md` exists so a referee can check that correspondence line by line,
and it is the place where an error would show.

A second, independent implementation — in another system, written without
copying this structure — would reduce the risk of a common-mode transcription
error. It does not exist yet.
