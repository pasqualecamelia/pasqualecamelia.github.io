"""
qgt_hydrogen.py — QGT Hydrogen Lock-in Simulator
Derivato da: The Quantum Gauge Theory of Time (Camelia, 2026)
CapMateria, CapOntologia, Gate Bohr-Rydberg (Level A chiuso, maggio 2026)

══════════════════════════════════════════════════════════════════
RUOLO DI QUESTO MODULO
══════════════════════════════════════════════════════════════════
Questo modulo è uno STRUMENTO NUMERICO DI VERIFICA, non una derivazione
QGT. Esso verifica che la scala a0_QGT derivata dalla catena interna

    S¹(τ) → Π⁺ → a₀_QGT → R_∞ → BASE → mₑ, mμ, mτ        [LEVEL_A]

sia consistente con la meccanica quantistica standard dell'atomo di
idrogeno, usandola come unica scala di lunghezza nell'Hamiltoniano
radiale adimensionale.

La convergenza numerica non implica né dimostra nulla di più: è
una verifica di consistenza. Il metodo ITP è uno standard della
fisica computazionale (Koonin & Meredith 1990, Press et al. 1992).

══════════════════════════════════════════════════════════════════
METODO: Imaginary-Time Propagation (ITP) con Crank-Nicolson
══════════════════════════════════════════════════════════════════
Hamiltoniano radiale adimensionale (unità atomiche, lunghezze in a₀_QGT):

    H = -1/2 · d²/dρ² - 1/ρ,    ρ = r / a₀_QGT

Discretizzazione alle differenze finite (centrate, ordine O(dρ²)):

    (-1/2) · d²u/dρ² ≈ [u_{i-1} - 2u_i + u_{i+1}] · (-1/2dρ²)
    → diagonale principale:  +1/dρ² - 1/ρᵢ
    → diagonali ±1:          -1/(2dρ²)

Schema Crank-Nicolson in tempo immaginario (stabile incondizionatamente):

    (I + dτ/2 · H) u_{k+1} = (I - dτ/2 · H) u_k
    u_{k+1} ←  u_{k+1} / ‖u_{k+1}‖_{L²}   (rinormalizzazione)

L'energia è misurata PRIMA del passo (stato u_k, non u_{k+1}):

    E_k = ⟨u_k | H | u_k⟩ = ∫ u_k · (Hu_k) dρ   [trapezoid]

Le energie {E_k} convergono monotonicamente verso l'autovalore minimo.

══════════════════════════════════════════════════════════════════
RISULTATI ATTESI (idrogenoide esatto, confronto con CODATA)
══════════════════════════════════════════════════════════════════
    E₁         = -1/2 a.u.  = -13.6057 eV   (NIST CODATA 2018)
    ρ_peak     = 1.000  (r_peak = a₀_QGT)
    ⟨ρ⟩        = 3/2   (⟨r⟩ = 3/2 · a₀_QGT)
    2⟨T⟩+⟨V⟩  → 0     (teorema del viriale)

Errore residuo atteso con N=600, ρ_max=25: ~ 4 meV interamente da
discretizzazione a griglia finita (O(dρ²) ~ O(25/600)² ~ 1.7e-3 a.u.).
Questo errore è << kT_ambiente = 26 meV; la soglia di convergenza
'converged' è fissata a 10 meV per questa ragione.

Riferimenti:
    Koonin & Meredith, Computational Physics (Addison-Wesley, 1990)
    Baye & Heenen, J. Phys. A 19 (1986) 2041
    Lehtovaara et al., J. Comput. Phys. 221 (2007) 148
"""

import numpy as np
from scipy.sparse import diags
from scipy.sparse.linalg import spsolve

from qgt_companion.qgt_core import (
    a0_QGT, CODATA,
    sigma1, H_ker, m_mu_me,
)

# ════════════════════════════════════════════════════════════════
# Costanti fisiche (CODATA 2018 / NIST)
# ════════════════════════════════════════════════════════════════
EV_PER_AU    = 27.211386245988    # 1 hartree = 27.211 eV  (CODATA 2018)
HBARC_MEV_M  = 197.3269804e-15   # ℏc = 197.327 MeV·fm  (CODATA 2018)
BOHR_M       = a0_QGT             # scala di lunghezza QGT [m]  (LEVEL_A)
BOHR_ANG     = BOHR_M * 1e10     # in Angstrom

# Energia esatta 1s (NIST 2018, 12 cifre significative)
E1S_EXACT_EV = -13.605693122994  # eV

# Soglia di convergenza: 10 meV << kT_ambiente (26 meV)
CONVERGENCE_THRESHOLD_EV = 0.010


# ════════════════════════════════════════════════════════════════
# 1. HAMILTONIANO SU GRIGLIA  (differenze finite O(dρ²))
# ════════════════════════════════════════════════════════════════

def build_hamiltonian_sparse(N=600, rho_max=25.0):
    """
    Hamiltoniano radiale H = -1/2 d²/dρ² - 1/ρ su griglia uniforme.

    Griglia: ρ_i = i·dρ, i=1..N, con dρ = rho_max/(N+1).
    Condizioni al contorno di Dirichlet: u(ρ_0=0) = u(ρ_{N+1}=rho_max) = 0.

    Discretizzazione (differenze finite centrate, O(dρ²)):
        H_{ii}   = +1/dρ² - 1/ρ_i       (termine T diag + V)
        H_{i,i±1}= -1/(2dρ²)             (termine T off-diag)

    Derivazione:
        -1/2 · (u_{i-1} - 2u_i + u_{i+1}) / dρ²
        = u_i/dρ² - (u_{i-1}+u_{i+1})/(2dρ²)
        → diag = +1/dρ², off-diag = -1/(2dρ²)
        + potenziale -1/ρ_i sulla diagonale

    Parametri
    ---------
    N       : numero di punti interni
    rho_max : troncamento del dominio (in unità a₀_QGT)

    Note
    ----
    rho_max = 25 è sufficiente per stati 1s-4s (la densità 4s
    scende a < 1e-6 per ρ > 20). Per stati n ≥ 5 usare rho_max ≥ 6n².
    """
    rho  = np.linspace(0.0, rho_max, N+2)[1:-1]   # punti interni
    drho = rho[1] - rho[0]                         # = rho_max/(N+1)

    diag_main = 1.0/drho**2 - 1.0/rho             # H_{ii}
    diag_off  = -0.5/drho**2 * np.ones(N-1)       # H_{i,i±1}

    H = diags([diag_off, diag_main, diag_off], [-1, 0, 1], format='csr')
    return rho, H


# ════════════════════════════════════════════════════════════════
# 2. ITP CRANK-NICOLSON — stato fondamentale
# ════════════════════════════════════════════════════════════════

def imaginary_time_propagation(N=600, rho_max=25.0,
                                n_steps=600, dtau=0.5,
                                verbose=False):
    """
    Calcola lo stato fondamentale 1s via ITP Crank-Nicolson.

    Lo stato iniziale è una gaussiana centrata su ρ=2.5 (intenzionalmente
    fuori equilibrio) per testare la convergenza dinamica.

    Parametri
    ---------
    N       : punti di griglia (default 600; errore ~4 meV)
    rho_max : troncamento dominio in a₀_QGT (default 25)
    n_steps : passi di tempo immaginario (default 600)
    dtau    : passo di tempo immaginario (default 0.5 a.u.)
    verbose : stampa E ogni 100 passi

    Note sul metodo
    ---------------
    L'energia E_k = ⟨u_k|H|u_k⟩ è calcolata prima del passo (stato u_k).
    Il passo CN risolve il sistema lineare sparso (I + dτ/2·H) u_{k+1} = rhs.
    La rinormalizzazione mantiene ‖u‖_{L²} = 1 dopo ogni passo.

    Osservabili
    -----------
    Tutte le medie ⟨·⟩ sono calcolate con la regola del trapezio
    (consistente per funzioni C² sulla griglia, errore O(dρ²)).

    Ritorna
    -------
    dict con chiavi:
        rho          : array griglia (a₀_QGT)
        u_final      : funzione d'onda radiale u(ρ) = ρ·R(ρ) normalizzata
        P_final      : densità radiale P(ρ) = u(ρ)²
        energy_ev    : energia finale in eV
        energies     : storia di E(τ) [eV], calcolata prima di ogni passo
        taus         : valori corrispondenti di τ
        converged    : True se |E_fin - E_esatto| < 10 meV
        r_peak_qgt   : ρ al picco di P(ρ) (atteso: 1.000)
        r_mean_qgt   : ⟨ρ⟩ = ∫ρ P dρ (atteso: 1.500)
        virial       : 2⟨T⟩+⟨V⟩ (atteso: 0)
        T_exp_au     : ⟨T⟩ in a.u.
        V_exp_au     : ⟨V⟩ in a.u.
        E_exact_eV   : riferimento NIST -13.605693122994 eV
        drho         : passo di griglia (per stima errore)
    """
    rho, H = build_hamiltonian_sparse(N, rho_max)
    drho   = rho[1] - rho[0]

    # Matrici CN (costruite una volta sola, riusate in ogni passo)
    I_sp   = diags(np.ones(N), format='csr')
    A_lhs  = I_sp + 0.5*dtau*H   # (I + dτ/2 H)  — sistema da risolvere
    A_rhs  = I_sp - 0.5*dtau*H   # (I - dτ/2 H)  — rhs

    # Stato iniziale: gaussiana fuori equilibrio, normalizzata in L²
    u = rho * np.exp(-(rho - 2.5)**2 / (2*1.2**2))
    u /= np.sqrt(np.trapezoid(u**2, rho))

    energies = []
    taus     = []

    for step in range(n_steps):
        # Energia calcolata sullo stato CORRENTE u_k (prima del passo)
        Hu = H @ u
        E  = float(np.trapezoid(u * Hu, rho))   # consistente con trapezoid
        energies.append(E * EV_PER_AU)
        taus.append(step * dtau)

        if verbose and step % 100 == 0:
            print(f"  step {step:4d}  E = {E*EV_PER_AU:+.6f} eV")

        # Passo CN
        rhs = A_rhs @ u
        u   = spsolve(A_lhs, rhs)

        # Rinormalizzazione
        norm = np.sqrt(np.trapezoid(u**2, rho))
        if norm < 1e-30:
            break
        u /= norm

    # ── Osservabili finali ──────────────────────────────────────
    Hu_fin = H @ u

    # Energia finale (trapezoid, consistente)
    E_fin_au = float(np.trapezoid(u * Hu_fin, rho))
    E_fin_ev = E_fin_au * EV_PER_AU

    P = u**2  # densità radiale

    # Raggio di picco e raggio medio
    r_peak = float(rho[np.argmax(P)])
    r_mean = float(np.trapezoid(rho * P, rho))

    # Teorema del viriale: 2⟨T⟩+⟨V⟩ → 0
    # Tutte le medie con trapezoid per consistenza
    V_exp = float(np.trapezoid(P * (-1.0/rho), rho))   # ⟨V⟩ = ⟨-1/ρ⟩
    T_exp = E_fin_au - V_exp                             # ⟨T⟩ = ⟨H⟩ - ⟨V⟩
    virial = 2*T_exp + V_exp                             # → 0

    return {
        'rho':        rho,
        'u_final':    u,
        'P_final':    P,
        'energy_ev':  E_fin_ev,
        'energies':   np.array(energies),
        'taus':       np.array(taus),
        # Soglia 10 meV << kT_ambiente=26 meV; errore residuo è
        # interamente da discretizzazione O(drho²) con drho~rho_max/N
        'converged':  abs(E_fin_ev - E1S_EXACT_EV) < CONVERGENCE_THRESHOLD_EV,
        'r_peak_qgt': r_peak,
        'r_mean_qgt': r_mean,
        'virial':     virial,
        'T_exp_au':   T_exp,
        'V_exp_au':   V_exp,
        'E_exact_eV': E1S_EXACT_EV,
        'drho':       drho,
        'N':          N,
        'rho_max':    rho_max,
    }


# ════════════════════════════════════════════════════════════════
# 3. STATI ECCITATI n=2,3,4  (deflazione di Gram-Schmidt + ITP CN)
# ════════════════════════════════════════════════════════════════

def excited_state(n, N=600, rho_max=None, n_steps=800, dtau=0.5):
    """
    Stato n-esimo dell'idrogeno via deflazione di Gram-Schmidt + ITP CN.

    Dopo ogni passo CN, u_{k+1} viene ortogonalizzato rispetto agli stati
    1..n-1 già convergenti (proiettori di deflazione). Questo forza la
    convergenza all'n-esimo autovalore anziché al fondamentale.

    Nota: il costo è O(n²) in chiamate ricorsive. Per n≥4 preferire
    la diagonalizzazione diretta (scipy.sparse.linalg.eigsh).

    Parametri
    ---------
    n       : numero quantico principale (2, 3, 4)
    N       : punti di griglia
    rho_max : dominio; default max(30, 6n²)
    n_steps : passi ITP
    dtau    : passo tempo immaginario
    """
    if rho_max is None:
        rho_max = max(30.0, 6*n*n)

    rho, H = build_hamiltonian_sparse(N, rho_max)
    drho   = rho[1] - rho[0]

    I_sp   = diags(np.ones(N), format='csr')
    A_lhs  = I_sp + 0.5*dtau*H
    A_rhs  = I_sp - 0.5*dtau*H

    # Calcola stati fondamentale..n-1 (deflazione)
    lower_states = []
    for k in range(1, n):
        if k == 1:
            res = imaginary_time_propagation(N=N, rho_max=rho_max,
                                             n_steps=n_steps, dtau=dtau)
        else:
            res = excited_state(k, N=N, rho_max=rho_max,
                                n_steps=n_steps, dtau=dtau)
        lower_states.append(res['u_final'])

    # Stato iniziale per n-esimo: gaussiana centrata su ρ≈n²
    u = rho * np.exp(-(rho - n*n)**2 / (2*(0.8*n)**2))
    # Gram-Schmidt: ortogonalizza rispetto agli stati inferiori
    for uk in lower_states:
        u -= float(np.trapezoid(uk * u, rho)) * uk
    norm = np.sqrt(np.trapezoid(u**2, rho))
    u /= max(norm, 1e-30)

    energies = []
    taus     = []

    for step in range(n_steps):
        Hu = H @ u
        E  = float(np.trapezoid(u * Hu, rho))
        energies.append(E * EV_PER_AU)
        taus.append(step * dtau)

        rhs = A_rhs @ u
        u   = spsolve(A_lhs, rhs)
        # Deflazione dopo ogni passo
        for uk in lower_states:
            u -= float(np.trapezoid(uk * u, rho)) * uk
        norm = np.sqrt(np.trapezoid(u**2, rho))
        if norm < 1e-30:
            break
        u /= norm

    Hu_fin   = H @ u
    E_fin_au = float(np.trapezoid(u * Hu_fin, rho))
    E_fin_ev = E_fin_au * EV_PER_AU
    P        = u**2
    r_peak   = float(rho[np.argmax(P)])
    r_mean   = float(np.trapezoid(rho * P, rho))
    E_exact  = E1S_EXACT_EV / n**2

    return {
        'n':          n,
        'rho':        rho,
        'u_final':    u,
        'P_final':    P,
        'energy_ev':  E_fin_ev,
        'energies':   np.array(energies),
        'taus':       np.array(taus),
        'converged':  abs(E_fin_ev - E_exact) < 0.05,
        'r_peak_qgt': r_peak,
        'r_mean_qgt': r_mean,
        'E_exact_eV': E_exact,
        'drho':       drho,
    }


# ════════════════════════════════════════════════════════════════
# 4. CASCATA BOHR-RYDBERG  (LEVEL_A, Gate chiuso maggio 2026)
# ════════════════════════════════════════════════════════════════

def bohr_rydberg_cascade():
    """
    Cascata interna QGT (LEVEL_A, CapMateria, Gate Bohr-Rydberg):

        S¹(τ) → Π⁺ → a₀_QGT → R_∞ → BASE → mₑ, mμ, mτ

    Formule:
        a₀_QGT  = Γ_τ² · M_B² · S^{-2r}  [m]   (Cap. Gate Bohr-Rydberg)
        R_∞     = α / (4π · a₀_QGT)            (relazione standard)
        mₑ      = 4π · ℏc · R_∞ / α²            (relazione di Rydberg)
        BASE    = mₑ·c² / (H₁ · σ₁)             (H₁=19, σ₁ strutturale)

    Nota: R_∞ è qui derivata da a₀_QGT usando α_CODATA. È il readout
    INTERNO della pseudo-inversa Π⁺ — non ancora una derivazione esterna
    indipendente [LEVEL_B per la connessione a R_∞].

    α usato: CODATA 137.035999177 (non α_QGT strutturale = 137.082)
    perché la cascata interpola tra la scala proiettiva e quella fisica.
    """
    alpha_phys  = 1.0 / CODATA['alpha_inv']
    a0_m        = a0_QGT                        # LEVEL_A

    R_infty_QGT = alpha_phys / (4*np.pi*a0_m)
    me_QGT_MeV  = 4*np.pi * HBARC_MEV_M * R_infty_QGT / alpha_phys**2
    BASE_keV    = me_QGT_MeV * 1e3 / (H_ker[0] * sigma1)

    return {
        'a0_QGT_m':     a0_m,
        'a0_QGT_ang':   a0_m * 1e10,
        'R_infty_QGT':  R_infty_QGT,
        'me_QGT_MeV':   me_QGT_MeV,
        'BASE_keV':      BASE_keV,
        'm_mu_me':       m_mu_me,
        'err_a0_ppm':   (a0_m / CODATA['a0']      - 1) * 1e6,
        'err_Rinf_ppm': (R_infty_QGT / CODATA['R_inf'] - 1) * 1e6,
        'err_me_pct':   (me_QGT_MeV  / CODATA['me_MeV'] - 1) * 100,
        'err_mumu_pct': (m_mu_me      / CODATA['m_mu_me'] - 1) * 100,
    }


# ════════════════════════════════════════════════════════════════
# 5. DENSITÀ RADIALE STATICA  (forme analitiche esatte, n=1..4)
# ════════════════════════════════════════════════════════════════

def hydrogen_radial_density(r_arr, n, a0=None):
    """
    Densità radiale P(r) = |R_{n0}(r)|² · r²  per stati s (l=0).

    Usa le funzioni radiali esatte di Laguerre (Griffiths, eq. 4.73).
    Normalizzazione: ∫₀^∞ P(r) dr = 1.

    Parametri
    ---------
    r_arr : array di r in Angstrom
    n     : numero quantico principale (1, 2, 3, 4)
    a0    : raggio di Bohr in Angstrom (default: a₀_QGT)
    """
    if a0 is None:
        a0 = BOHR_ANG
    rho = 2 * r_arr / (n * a0)
    if   n == 1: Rnl = 2 * np.exp(-rho/2)
    elif n == 2: Rnl = (1/(2*np.sqrt(2))) * (2 - rho) * np.exp(-rho/2)
    elif n == 3: Rnl = (2/(81*np.sqrt(3))) * (27 - 18*rho + 2*rho**2) * np.exp(-rho/2)
    elif n == 4: Rnl = (1/768) * (192 - 144*rho + 24*rho**2 - rho**3) * np.exp(-rho/2)
    else:        Rnl = np.exp(-rho/2)
    return Rnl**2 * r_arr**2
