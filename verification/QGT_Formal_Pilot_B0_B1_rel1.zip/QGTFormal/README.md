# QGT formal pilot — B0_min + B1_arith

A kernel-checked formalization of the arithmetic core of Appendix L of the
frozen **QGT First Edition v7.6.6**: the projection invariant `20 phi^4` read
through the Pincherle dilatation, the Fibonacci quadratic norm in `Z[sqrt5]`
and the regular matrix representation, proved exactly equal.

## Reproduce

```bash
lake build                    # 11 targets, no dependencies
bash scripts/audit.sh         # forbidden shortcuts + #print axioms
python3 scripts/hash_manifest.py
```

Requires only a Lean 4.22.0 toolchain. **mathlib is not used**: the project
builds from Lean core alone.

## What is proved

`QGT.crossRepresentation` — the central theorem — states that the Pincherle
residue squared, the golden quadratic form on the Fibonacci pair, and the
evaluation of the regular representation of `M_Pi^2` are all equal to
`20 phi^4`, in the ring of integers of `Q(sqrt 5)`. Ten of the twelve exported
theorems depend on **no axioms at all**.

`QGT.finiteRankSensitivity` — a finite negative control: the closure holds at
rank five and fails at ranks 3, 4, 6 and 7.

## What is not proved

Read `FORMALIZATION_CONTRACT.md` before citing anything from this project. In
short: rank five is an imported upstream input, not a result; the carrier is
`Z[phi]` and no statement about the reals is made; the negative control is
finite and is not a uniqueness theorem; and nothing here bears on the physical
truth of QGT or on the empirical identity of the invariant with the measured
fine-structure constant.
