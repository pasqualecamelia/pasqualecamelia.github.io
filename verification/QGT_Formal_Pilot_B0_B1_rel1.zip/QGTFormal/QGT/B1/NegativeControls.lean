/-
QGT Formal Pilot — B1: finite negative controls.

Replacing the imported rank by neighbouring values and keeping everything else
fixed, the downstream arithmetic no longer reproduces the invariant.

This is a FINITE SENSITIVITY THEOREM over the declared set r in {3,4,5,6,7}.
It is NOT a proof that rank five is unique: that theorem is upstream and is
not formalized in this pilot.
-/
import QGT.B1.Readouts

namespace QGT
open Zphi

/-- The readout obtained from the coefficient pair of rank `r`. -/
def rankReadout (r : Nat) : Zphi := normReadout (fib r) (fib (r - 1))

theorem rank_three_fails : rankReadout 3 ≠ twentyPhiFour := by decide
theorem rank_four_fails  : rankReadout 4 ≠ twentyPhiFour := by decide
theorem rank_five_closes : rankReadout 5 = twentyPhiFour := by decide
theorem rank_six_fails   : rankReadout 6 ≠ twentyPhiFour := by decide
theorem rank_seven_fails : rankReadout 7 ≠ twentyPhiFour := by decide

/-- Finite negative control over the declared set. -/
theorem finiteRankSensitivity :
    rankReadout 5 = twentyPhiFour
    ∧ rankReadout 3 ≠ twentyPhiFour
    ∧ rankReadout 4 ≠ twentyPhiFour
    ∧ rankReadout 6 ≠ twentyPhiFour
    ∧ rankReadout 7 ≠ twentyPhiFour := by
  refine ⟨?_, ?_, ?_, ?_, ?_⟩ <;> decide

end QGT
