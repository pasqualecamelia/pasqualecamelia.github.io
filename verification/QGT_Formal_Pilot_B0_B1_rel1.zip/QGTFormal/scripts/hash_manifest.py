#!/usr/bin/env python3
"""Freeze the pilot: hash every source file and record the toolchain."""
import hashlib, json, os, platform, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def sha(p):
    with open(p, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()

files = {}
for base, dirs, names in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in (".lake", ".git")]
    for n in sorted(names):
        if n == "MANIFEST.json":
            continue
        p = os.path.join(base, n)
        files[os.path.relpath(p, ROOT)] = sha(p)

try:
    lean_v = subprocess.run(["lean", "--version"], capture_output=True,
                            text=True).stdout.strip()
except Exception:
    lean_v = "unavailable"

manifest = {
    "project": "QGTFormal",
    "pilot": "B0_min + B1_arith",
    "authority": {
        "work": "QGT First Edition v7.6.6 (frozen)",
        "appendix": "Appendix L — The Projection Constant (pp. 529-537, nine readings)",
        "source_label": "app:alpha_structure",
    },
    "toolchain": {
        "lean": lean_v,
        "mathlib": None,
        "note": "builds from Lean core alone; no external dependency",
        "platform": platform.platform(),
    },
    "theorems": [
        {"lean": "QGT.chiral_contraction", "tag": "I.1", "status": "proved",
         "axioms": ["propext", "Quot.sound"], "note": "scaled form"},
        {"lean": "QGT.pincherleReadout", "tag": "I.4", "status": "proved",
         "axioms": []},
        {"lean": "QGT.fibonacciNormReadout", "tag": "II.1", "status": "proved",
         "axioms": [], "upstream": ["rank_five", "fibonacci_pair"]},
        {"lean": "QGT.regularMatrixReadout", "tag": "II.2", "status": "proved",
         "axioms": []},
        {"lean": "QGT.crossRepresentation", "tag": "I.4/II.1/II.2",
         "status": "proved", "axioms": [],
         "upstream": ["rank_five", "fibonacci_pair"]},
        {"lean": "QGT.finiteRankSensitivity", "tag": "negative control",
         "status": "proved", "axioms": [], "domain": "r in {3,4,5,6,7}"},
    ],
    "forbidden_shortcuts": {"sorry": 0, "admit": 0, "unsafe": 0,
                            "native_decide": 0},
    "empirical_inputs": [],
    "files_sha256": files,
    "status": "PASS",
    "scope": ("conditional on the declared rank-five and golden-structure "
              "inputs; no physical claim"),
}
blob = json.dumps(manifest, indent=2, sort_keys=False)
with open(os.path.join(ROOT, "MANIFEST.json"), "w") as fh:
    fh.write(blob)
print("MANIFEST.json written: %d files hashed" % len(files))
