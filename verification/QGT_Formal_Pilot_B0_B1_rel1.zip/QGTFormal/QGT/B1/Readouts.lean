/-
QGT Formal Pilot — B1: the four readouts of the projection invariant.

T2  Pincherle dilatation residue
T3  Fibonacci quadratic norm in Z[sqrt5]
T4  regular matrix representation
T5  cross-representation coherence

Every theorem that uses the rank takes the B0 contract as an explicit
hypothesis. No theorem defines its own conclusion.
-/
import QGT.Foundations.Golden
import QGT.Foundations.Fibonacci
import QGT.Foundations.QuadraticSqrtFive
import QGT.Foundations.RegularRepresentation
import QGT.B0.RankFiveContract

namespace QGT
open Zphi

/-! ### T2 — Pincherle dilatation residue -/

/-- The spectral curvature `kappa = phi + phi^{-1}`, built as `phi + (phi-1)`. -/
def kappa : Zphi := phi + (phi - 1)

theorem kappa_eq_sqrt5 : kappa = sqrt5 := by decide

/-- `Lambda_Pi = 2 phi^2 sqrt5`, constructed, not asserted. -/
def LambdaPi : Zphi := smul 2 (phi * phi * sqrt5)

theorem LambdaPi_alt : LambdaPi = ofInt 5 + smul 3 sqrt5 := by decide

/-- T2: the square of the dilatation residue is the projection invariant. -/
theorem pincherleReadout : LambdaPi * LambdaPi = twentyPhiFour := by decide

/-! ### T3 — Fibonacci quadratic norm -/

/-- The readout of a coefficient pair through the golden quadratic form. -/
def normReadout (a b : Int) : Zphi := goldenNorm a b

/-- T3: on the Fibonacci pair supplied by the upstream contract, the golden
    quadratic form evaluates to the projection invariant. The dependence on
    the rank-five selection is explicit in the hypothesis `h`. -/
theorem fibonacciNormReadout (S : RankSelection) :
    normReadout S.coeff_hi S.coeff_lo = twentyPhiFour := by
  obtain ⟨h1, h2⟩ := S.coeff_is_fib
  rw [h1, h2]
  decide

/-- The same readout, stated on the concrete pair, equal to `70 + 30 sqrt5`. -/
theorem fibonacciNorm_surd : normReadout 5 3 = evalSqrt5 70 30 := by decide

/-! ### T4 — regular matrix representation -/

/-- `M_Pi` built from the coefficient pair supplied by the upstream contract:
    `[[c_hi, 5 c_lo], [c_lo, c_hi]]`. -/
def MPiOf (S : RankSelection) : Mat2 :=
  ⟨S.coeff_hi, 5 * S.coeff_lo, S.coeff_lo, S.coeff_hi⟩

/-- The concrete matrix, as printed in the monograph. -/
def MPi : Mat2 := ⟨fib 5, 5 * fib 4, fib 4, fib 5⟩

theorem MPiOf_upstream : MPiOf upstream = MPi := by decide

theorem MPi_val : MPi = ⟨5, 15, 3, 5⟩ := by decide

theorem MPi_trace : MPi.trace = 10 := by decide

theorem MPi_det : MPi.det = fib 5 * fib 5 - 5 * (fib 4 * fib 4) := by decide

theorem MPi_det_val : MPi.det = -20 := by decide

theorem MPi_sq_val : Mat2.mul MPi MPi = ⟨70, 150, 30, 70⟩ := by decide

/-- The square lies in the image of the regular representation. -/
theorem MPi_sq_regular : isRegular (Mat2.mul MPi MPi) := by decide

/-- T4: evaluating the regular representation of `M_Pi^2` gives the invariant. -/
theorem regularMatrixReadout (S : RankSelection) :
    evalSqrt5 (Mat2.mul (MPiOf S) (MPiOf S)).m00
              (Mat2.mul (MPiOf S) (MPiOf S)).m10 = twentyPhiFour := by
  obtain ⟨h1, h2⟩ := S.coeff_is_fib
  unfold MPiOf
  rw [h1, h2]
  decide

/-- The same readout on the concrete matrix printed in the monograph. -/
theorem regularMatrixReadout_concrete :
    evalSqrt5 (Mat2.mul MPi MPi).m00 (Mat2.mul MPi MPi).m10 = twentyPhiFour := by
  decide

/-! ### T5 — cross-representation coherence -/

/-- T5, the central theorem of the pilot: the Pincherle residue, the Fibonacci
    quadratic norm and the regular matrix representation are exactly equal, and
    equal to `20 phi^4`. The rank-five and Fibonacci-pair inputs enter through
    the explicit contract hypothesis. -/
theorem crossRepresentation (S : RankSelection) :
    LambdaPi * LambdaPi = normReadout S.coeff_hi S.coeff_lo
    ∧ normReadout S.coeff_hi S.coeff_lo
        = evalSqrt5 (Mat2.mul (MPiOf S) (MPiOf S)).m00
                    (Mat2.mul (MPiOf S) (MPiOf S)).m10
    ∧ evalSqrt5 (Mat2.mul (MPiOf S) (MPiOf S)).m00
                (Mat2.mul (MPiOf S) (MPiOf S)).m10 = twentyPhiFour := by
  obtain ⟨h1, h2⟩ := S.coeff_is_fib
  refine ⟨?_, ?_, ?_⟩
  · rw [h1, h2]; decide
  · rw [h1, h2]; unfold MPiOf; rw [h1, h2]; decide
  · unfold MPiOf; rw [h1, h2]; decide

end QGT
